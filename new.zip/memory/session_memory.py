class SessionMemory:
    def __init__(self, max_history: int = 10):
        self.max_history = max_history
        self.history = []

    def add_interaction(self, user_text: str, ai_response: str):
        self.history.append((user_text, ai_response))
        if len(self.history) > self.max_history:
            self.history.pop(0)

    def get_context_summary(self) -> str:
        if not self.history:
            return ""
        summary = []
        for user, ai in self.history:
            summary.append(f"사용자: {user}\nAI: {ai}")
        return "\n".join(summary)

    def clear(self):
        self.history.clear()