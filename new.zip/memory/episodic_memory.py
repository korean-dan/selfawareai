import sqlite3
import logging
from typing import List, Tuple
from datetime import datetime
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np

class EpisodicMemory:
    def __init__(self, db_path: str = "data/episodic_memory.db"):
        self.db_path = db_path
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.cur = self.conn.cursor()
        self._initialize_db()

    def _initialize_db(self):
        with self.conn:
            self.cur.execute('''
                CREATE TABLE IF NOT EXISTS memory (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    context TEXT NOT NULL,
                    response TEXT NOT NULL,
                    accuracy REAL CHECK(accuracy BETWEEN 0 AND 1),
                    emotion TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')

    def store_episode(self, context: str, response: str, accuracy: float = 1.0, emotion: str = "중립") -> None:
        try:
            with self.conn:
                self.cur.execute(
                    '''
                    INSERT INTO memory (context, response, accuracy, emotion, created_at)
                    VALUES (?, ?, ?, ?, ?)
                    ''',
                    (context, response, accuracy, emotion, datetime.now())
                )
        except sqlite3.Error as e:
            logging.error(f"[EpisodicMemory] 저장 오류: {e}")

    def get_recent_episodes(self, limit: int = 10) -> List[Tuple[str, str, float, str, str]]:
        self.cur.execute(
            '''
            SELECT context, response, accuracy, emotion, created_at
            FROM memory
            ORDER BY created_at DESC
            LIMIT ?
            ''',
            (limit,)
        )
        return self.cur.fetchall()

    def recall_by_context(self, query: str) -> Tuple[str, str, float, str]:
        self.cur.execute(
            'SELECT context, response, accuracy, emotion FROM memory ORDER BY created_at DESC LIMIT 100'
        )
        records = self.cur.fetchall()

        if not records:
            return "기억 없음", "응답 없음", 0.0, "중립"

        contexts = [rec[0] for rec in records]
        tfidf = TfidfVectorizer().fit_transform(contexts + [query])
        vectors = tfidf.toarray()

        similarity_scores = cosine_similarity([vectors[-1]], vectors[:-1])[0]
        best_match_index = np.argmax(similarity_scores)

        best_record = records[best_match_index]
        return best_record  # (context, response, accuracy, emotion)

    def get_episode_by_index(self, index: int) -> Tuple[str, str, float, str, str]:
        self.cur.execute(
            'SELECT context, response, accuracy, emotion, created_at FROM memory ORDER BY created_at DESC LIMIT 1 OFFSET ?',
            (index,)
        )
        return self.cur.fetchone()

    def close(self):
        if self.conn:
            self.conn.close()
            self.conn = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()