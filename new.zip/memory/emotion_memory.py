import sqlite3
import logging
import random
from typing import List, Tuple
from datetime import datetime, timedelta

class EmotionMemory:
    def __init__(self, memory_file: str = 'data/emotion_memory.db', max_storage: int = 100):
        self.memory_file = memory_file
        self.max_storage = max_storage
        self.conn = sqlite3.connect(self.memory_file, check_same_thread=False)
        self._initialize_db()

    def _initialize_db(self) -> None:
        with self.conn:
            self.conn.execute('''
                CREATE TABLE IF NOT EXISTS emotions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    text TEXT NOT NULL,
                    emotion TEXT NOT NULL,
                    confidence REAL NOT NULL CHECK(confidence BETWEEN 0 AND 1),
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            ''')

    def store_emotion(self, text: str, emotion: str, confidence: float) -> None:
        confidence = max(0.0, min(confidence, 1.0))
        try:
            with self.conn:
                self.conn.execute(
                    'INSERT INTO emotions (text, emotion, confidence, timestamp) VALUES (?, ?, ?, ?)',
                    (text, emotion, confidence, datetime.now())
                )
            self._cleanup_emotions()
        except sqlite3.Error as e:
            logging.error(f"[EmotionMemory] 감정 저장 오류: {e}")

    def _cleanup_emotions(self):
        with self.conn:
            self.conn.execute(f'''
                DELETE FROM emotions WHERE id NOT IN (
                    SELECT id FROM emotions ORDER BY timestamp DESC LIMIT {self.max_storage}
                )
            ''')

    def get_emotion_history(self, limit: int = 20, time_sensitive: bool = True) -> List[Tuple[int, str, str, float, str]]:
        cur = self.conn.cursor()
        cur.execute(
            'SELECT id, text, emotion, confidence, timestamp FROM emotions ORDER BY id DESC LIMIT ?',
            (limit,)
        )
        records = cur.fetchall()

        if time_sensitive:
            updated_records = []
            for rec in records:
                emotion_id, text, emotion, confidence, timestamp = rec
                dt = datetime.strptime(timestamp, "%Y-%m-%d %H:%M:%S")
                time_diff = (datetime.now() - dt).total_seconds()
                decay_factor = max(0.1, 1 - (time_diff / (60 * 60 * 24 * 7)))  # 7일 기준 휘발
                updated_records.append((emotion_id, text, emotion, confidence * decay_factor, timestamp))
            return updated_records

        return records

    def recall_emotion(self, text: str) -> Tuple[str, float]:
        cur = self.conn.cursor()
        cur.execute('SELECT emotion, confidence FROM emotions ORDER BY id DESC LIMIT 100')
        records = cur.fetchall()
        if not records:
            return "중립", 0.5
        return random.choice(records)

    def forget_old_emotions(self) -> None:
        try:
            expiration_time = datetime.now() - timedelta(days=30)
            with self.conn:
                self.conn.execute(
                    'DELETE FROM emotions WHERE timestamp < ?',
                    (expiration_time.strftime("%Y-%m-%d %H:%M:%S"),)
                )
        except sqlite3.Error as e:
            logging.error(f"[EmotionMemory] 오래된 감정 삭제 오류: {e}")

    def close(self) -> None:
        if self.conn:
            self.conn.close()
            self.conn = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()