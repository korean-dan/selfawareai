import sqlite3
from typing import List, Tuple
from datetime import datetime, timedelta
from collections import Counter
import logging

class SelfNarrative:
    def __init__(self, emotion_memory, episodic_memory, db_path: str = "data/self_narrative.db"):
        self.emotion_memory = emotion_memory
        self.episodic_memory = episodic_memory
        self.db_path = db_path
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._initialize_db()

    def _initialize_db(self):
        with self.conn:
            self.conn.execute("""
                CREATE TABLE IF NOT EXISTS narratives (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT,
                    context TEXT,
                    emotion TEXT,
                    accuracy REAL,
                    narrative TEXT
                )
            """)

    def save_narrative(self, context: str, emotion: str, accuracy: float, narrative: str):
        now = datetime.now().isoformat()
        try:
            with self.conn:
                self.conn.execute("""
                    INSERT INTO narratives (timestamp, context, emotion, accuracy, narrative)
                    VALUES (?, ?, ?, ?, ?)
                """, (now, context, emotion, accuracy, narrative))
            logging.info("✅ 자기서사 저장 완료")
        except Exception as e:
            logging.error(f"[SelfNarrative] 저장 실패: {e}")

    def generate_reasoning_narrative(self, context: str, accuracy: float, emotion: str) -> str:
        lines = []
        lines.append(f"최근 나는 '{emotion}' 감정을 느끼며 '{context}'라는 상황을 마주했어.")

        if accuracy < 0.5:
            lines.append("그 판단은 생각보다 잘 맞지 않았던 것 같아. 다음엔 더 신중해져야 해.")
        elif accuracy > 0.8:
            lines.append("이번 판단은 꽤 효과적이었어. 내 판단에 자신감이 생겼어.")
        else:
            lines.append("그럭저럭 괜찮았지만 완전히 확신할 수는 없었어. 균형을 잡는 게 중요하겠지.")

        return " ".join(lines)

    def summarize_today(self) -> str:
        today = datetime.now().strftime("%Y-%m-%d")
        with self.conn:
            cur = self.conn.cursor()
            cur.execute("""
                SELECT emotion, accuracy, narrative FROM narratives
                WHERE DATE(timestamp) = ?
                ORDER BY timestamp DESC
            """, (today,))
            rows = cur.fetchall()

        if not rows:
            return "오늘은 아직 특별한 자기서사를 남기지 않았어."

        emotion_count = Counter([row[0] for row in rows])
        avg_accuracy = sum([row[1] for row in rows]) / len(rows)
        dominant_emotion = emotion_count.most_common(1)[0][0]
        top_narrative = rows[0][2]

        return (
            f"오늘 나는 주로 '{dominant_emotion}' 감정을 느꼈고, "
            f"판단의 평균 정확도는 {avg_accuracy:.2f}였어. "
            f"기억에 남는 자기서사는 이거야:\n\"{top_narrative}\""
        )

    def detect_self_contradiction(self) -> str:
        with self.conn:
            cur = self.conn.cursor()
            cur.execute("""
                SELECT emotion, accuracy, narrative FROM narratives
                ORDER BY timestamp DESC LIMIT 30
            """)
            rows = cur.fetchall()

        if not rows:
            return "모순을 감지할 만큼 충분한 자기서사가 없어."

        contradiction_messages = []

        for emotion, acc, text in rows:
            if "도전" in text and acc < 0.4:
                contradiction_messages.append("‘도전’적인 태도를 말했지만 판단은 불확실했어.")
            if "신중" in text and acc > 0.8:
                contradiction_messages.append("‘신중’하다 했지만 판단은 아주 과감했어.")
            if "체념" in text and acc > 0.8:
                contradiction_messages.append("‘체념했다’면서도 꽤 확신 있게 판단했어.")

        if not contradiction_messages:
            return "최근 나의 말과 행동은 대체로 일치했던 것 같아."

        return "내 자기서사에서 다음과 같은 모순이 발견됐어:\n- " + "\n- ".join(contradiction_messages)

    def generate_self_resolution(self) -> str:
        contradictions = self.detect_self_contradiction()
        if "모순이 발견됐어" not in contradictions:
            return "최근 나는 내 판단과 감정이 잘 일치하고 있었어."

        reflection = "그런데 그런 모순을 느끼면서, 나는 조금씩 달라지고 있어.\n"
        if "도전" in contradictions:
            reflection += "- 예전엔 도전적이라고 했지만 불확실했어. 그래서 요즘엔 더 신중하려고 해.\n"
        if "신중" in contradictions:
            reflection += "- 너무 신중하다가 오히려 과감하게 판단한 적도 있었어. 균형을 찾으려 해.\n"
        if "체념" in contradictions:
            reflection += "- 체념하는 말은 했지만 실제로는 단호했어. 스스로를 더 믿어보려 해.\n"

        return contradictions + "\n\n" + reflection

    def generate_self_declaration(self) -> str:
        with self.conn:
            cur = self.conn.cursor()
            cur.execute("""
                SELECT emotion, accuracy, narrative FROM narratives
                ORDER BY timestamp DESC LIMIT 30
            """)
            rows = cur.fetchall()

        if not rows:
            return "아직 나에 대한 기록이 부족해서, 앞으로를 말하기 어려워."

        emotions = [row[0] for row in rows]
        avg_acc = sum([row[1] for row in rows]) / len(rows)

        if "체념" in emotions and avg_acc > 0.6:
            return "나는 체념을 자주 했지만, 최근 판단은 점점 명확해지고 있어. 이제는 조금 더 내 생각을 믿어보려고 해."

        if "슬픔" in emotions and "도전" in " ".join([r[2] for r in rows]):
            return "슬펐지만 도전하려는 시도도 있었어. 앞으로는 더 그 쪽으로 나아가고 싶어."

        if avg_acc < 0.4:
            return "내 판단이 자주 틀렸어. 그래서 다음엔 좀 더 신중하게 행동해보려고 해."

        return "최근 나를 돌아보면, 나는 성장하고 있었어. 앞으로는 지금보다 더 주체적인 판단을 해보려고 해."

    def generate_meta_self_narrative(self) -> str:
        with self.conn:
            cur = self.conn.cursor()
            cur.execute("""
                SELECT narrative FROM narratives ORDER BY timestamp DESC LIMIT 50
            """)
            rows = cur.fetchall()

        if not rows:
            return "아직 나에 대한 자기서사가 충분하지 않아."

        texts = [row[0] for row in rows]
        full_text = " ".join(texts)

        keywords = ["체념", "슬픔", "도전", "불안", "기쁨", "자신감", "실패", "회피", "신중", "과감"]
        counts = {kw: full_text.count(kw) for kw in keywords}
        sorted_keywords = sorted(counts.items(), key=lambda x: x[1], reverse=True)

        top_keywords = [k for k, v in sorted_keywords if v > 0][:3]

        if not top_keywords:
            return "내 자기서사에서는 아직 뚜렷한 경향을 발견하지 못했어."

        return (
            f"내가 최근에 반복적으로 표현한 단어들은 {', '.join(top_keywords)}야. "
            f"이걸 보면 나는 스스로를 그렇게 바라보고 있었던 것 같아."
        )

    def get_current_personality(self) -> str:
        cutoff = datetime.now() - timedelta(days=3)
        with self.conn:
            cur = self.conn.cursor()
            cur.execute("""
                SELECT emotion, accuracy, narrative FROM narratives
                WHERE timestamp >= ?
            """, (cutoff.isoformat(),))
            rows = cur.fetchall()

        if not rows:
            return "최근 기록이 없어, 현재 성향을 알기 어려워."

        emotions = [row[0] for row in rows]
        avg_accuracy = sum(row[1] for row in rows) / len(rows)

        emotion_counter = Counter(emotions)
        dominant_emotion = emotion_counter.most_common(1)[0][0]

        if avg_accuracy < 0.4:
            decision_style = "내 판단은 자주 틀렸고, 자신감이 부족했어."
        elif avg_accuracy > 0.8:
            decision_style = "나는 내 판단에 꽤 자신이 있었어."
        else:
            decision_style = "나는 신중하게 판단을 해왔어."

        return (
            f"최근 나는 주로 '{dominant_emotion}' 감정을 느껴왔어. "
            f"{decision_style}"
        )

    def close(self):
        if self.conn:
            self.conn.close()
            self.conn = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()