import sqlite3
import requests
import logging
from typing import Optional, Dict, List
from collections import Counter

class KnowledgeBase:
    def __init__(self, db_path: str = "data/knowledge_base.db"):
        self.db_path = db_path
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.cur = self.conn.cursor()
        self._initialize_db()
        self.cache = {}

    def _initialize_db(self):
        with self.conn:
            self.cur.execute('''
                CREATE TABLE IF NOT EXISTS knowledge (
                    concept TEXT PRIMARY KEY,
                    definition TEXT
                )
            ''')

    def search_and_learn(self, concept: str) -> str:
        import faiss
        import numpy as np
        from sentence_transformers import SentenceTransformer
        import requests

        model = SentenceTransformer("all-MiniLM-L6-v2")
        index = faiss.IndexFlatL2(384)

        vec = model.encode([concept])
        D, I = index.search(np.array(vec).astype('float32'), k=1)

        if D[0][0] < 0.5:
            return "기존 지식 있음."
        else:
            url = f"https://en.wikipedia.org/api/rest_v1/page/summary/{concept}"
            response = requests.get(url)
            if response.status_code == 200:
                data = response.json()
                definition = data.get("extract", "정의를 찾을 수 없습니다.")
                self.save_knowledge(concept, definition)
                return definition
            else:
                return "검색 결과가 없습니다."

    def save_knowledge(self, concept: str, definition: str):
        try:
            with self.conn:
                self.cur.execute(
                    "INSERT OR REPLACE INTO knowledge (concept, definition) VALUES (?, ?)",
                    (concept, definition)
                )
        except sqlite3.Error as e:
            logging.error(f"[KnowledgeBase] 지식 저장 오류: {e}")

    def check_knowledge(self, concept: str) -> str:
        if concept in self.cache:
            return self.cache[concept]

        self.cur.execute("SELECT definition FROM knowledge WHERE concept=?", (concept,))
        result = self.cur.fetchone()
        if result:
            self.cache[concept] = result[0]
            return result[0]

        return self.search_and_learn(concept)

    def get_all_knowledge(self) -> List[Dict[str, str]]:
        self.cur.execute("SELECT concept, definition FROM knowledge ORDER BY concept")
        return [{"concept": c, "definition": d} for c, d in self.cur.fetchall()]

    def express_random_knowledge(self) -> str:
        self.cur.execute("SELECT concept, definition FROM knowledge ORDER BY RANDOM() LIMIT 1")
        result = self.cur.fetchone()
        if result:
            return f"'{result[0]}'은(는) 이렇게 정의돼 있어: {result[1]}"
        return "아직 학습한 개념이 없어."

    def close(self):
        self.conn.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()