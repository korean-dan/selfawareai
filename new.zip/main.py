from agent.self_model import SelfAwareAI

if __name__ == "__main__":
    try:
        ai = SelfAwareAI()
        ai.chat()
    except KeyboardInterrupt:
        print("\n[시스템 종료] 사용자에 의해 중단되었습니다.")
    finally:
        ai.close()
        print("[AI 종료] 감정, 기억, 사고 시스템을 안전하게 종료했습니다.")