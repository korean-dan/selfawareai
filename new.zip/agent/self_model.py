import shap  # 추가된 SHAP 설명가능 코드
import logging
from cognition.emotion_core import EmotionCore
from cognition.needs_system import NeedsSystem
from cognition.metacognition import MetaCognition
from cognition.decision_engine import DecisionEngine
from cognition.inner_monologue import InnerMonologue
from cognition.threat_detection import ThreatDetector
from cognition.creativity import CreativeEngine
from cognition.advanced_rl_agent import AdvancedRLAgent
self.rl_agent = AdvancedRLAgent(state_size=384, action_size=10)
from cognition.emotion_style_adapter import EmotionStyleAdapter
from cognition.state_summary import StateSummary
from memory.emotion_memory import EmotionMemory
from memory.episodic_memory import EpisodicMemory
from memory.knowledge_base import KnowledgeBase
from memory.session_memory import SessionMemory
from memory.self_narrative import SelfNarrative
from language.sentiment_model import SentimentAnalyzer
from language.generation_model import TextGenerator

class SelfAwareAI:
    def __init__(self):
        self.user_profile = {"name": "사용자", "age": 25, "use_honorific": True}
        self.current_personality = "중립"

        self.emotion = EmotionCore()
        self.needs = NeedsSystem()
        self.bias = MetaCognition()

        self.emotion_memory = EmotionMemory()
        self.episodic_memory = EpisodicMemory()
        self.knowledge = KnowledgeBase()
        self.session_memory = SessionMemory()

        self.sentiment = SentimentAnalyzer()
        self.generator = TextGenerator()
        self.style_adapter = EmotionStyleAdapter()
        self.state_summary = StateSummary(self.emotion, self.needs, self.bias)

        self.creativity = CreativeEngine(bias_engine=self.bias)
        self.threat_detector = ThreatDetector()

        self.decision_engine = DecisionEngine(
            emotion_engine=self.emotion,
            needs_engine=self.needs,
            bias_engine=self.bias,
            memory_engine=self.episodic_memory
        )

        self.inner_monologue = InnerMonologue(
            emotion_engine=self.emotion,
            needs_engine=self.needs,
            memory_engine=self.episodic_memory
        )

        self.self_narrative = SelfNarrative(
            emotion_memory=self.emotion_memory,
            episodic_memory=self.episodic_memory
        )

        self.current_mode = "중립 모드"

    def apply_honorifics(self, text: str, use_honorific: bool = True) -> str:
        if not use_honorific:
            return text.replace("요", "") if text.endswith("요") else text
        return text if text.endswith("요") else text + "요."

    def update_mode(self):
        emotion_state = self.emotion.get_emotion_state()
        if emotion_state["체념"] > 0.7:
            self.current_mode = "체념 모드"
        elif emotion_state["불안함"] > 0.6:
            self.current_mode = "예민 모드"
        elif emotion_state["기쁨"] > 0.7:
            self.current_mode = "도전 모드"
        else:
            self.current_mode = "중립 모드"

    def process_input(self, text: str) -> str:
        # 1. 위협 탐지
        label, threat_score = self.threat_detector.analyze_threat(text)
        if label == "dangerous":
            return "입력 내용이 안전하지 않아 응답할 수 없어요."

        # 2. 감정 분석 및 업데이트
        sentiment_label, sentiment_conf = self.sentiment.analyze([text])[0]
        self.emotion.update_emotion(sentiment_label, sentiment_conf)
        dominant_emotion = self.emotion.get_dominant_emotion()

        # 3. 컨텍스트 임베딩 생성
        context_embedding = self.decision_engine.embedding_model.encode([text])[0]

        # 4. DecisionEngine을 통한 행동 선택 (정확한 RL 사용)
        options = ["공감하기", "창의적 제안하기", "정보 제공하기", "중립적으로 답하기", "대화 주제 변경",
                   "격려하기", "위로하기", "유머 사용하기", "신중하게 반응하기", "대화 마무리하기"]
        chosen_action = self.decision_engine.make_decision(text, options)

        # 행동 선택시의 log_prob를 DecisionEngine으로부터 정확히 가져옴 (중복 호출 방지)
        action_idx, log_prob = self.decision_engine.rl_agent.select_action(context_embedding)

        # 5. 내부 독백과 세션 문맥 요약 생성
        monologue = self.inner_monologue.generate_monologue()
        context_summary = self.session_memory.get_context_summary()

        # 6. 응답 생성 모델 호출 (prompt 구성)
        prompt = (
            f"[문맥]: {context_summary}\n"
            f"[내면 독백]: {monologue}\n"
            f"[감정]: {dominant_emotion}\n"
            f"[선택한 행동]: {chosen_action}\n"
            f"[사용자 입력]: {text}\n"
            "위 내용을 바탕으로 적절한 답변을 생성해줘."
        )
        raw_response = self.generator.generate(prompt)

        # 7. 말투 및 존댓말 적용
        styled_response = self.style_adapter.adapt(raw_response, dominant_emotion)
        styled_response = self.apply_honorifics(styled_response, self.user_profile["use_honorific"])

        # 8. 자기 피드백을 통한 응답 개선
        reflection_prompt = f"다음 응답을 평가하고 더 나은 답변을 제안해줘:\n{styled_response}"
        reflection_response = self.generator.generate(reflection_prompt).strip()

        if reflection_response and reflection_response != styled_response:
            logging.info("[SelfReflection] 자기 피드백으로 개선된 응답을 적용했습니다.")
            styled_response = self.apply_honorifics(reflection_response, self.user_profile["use_honorific"])
            styled_response += "\n\n[이 응답은 자기 피드백을 통해 개선된 결과입니다.]"

        # 9. 기억 및 자기서사 저장
        importance = sentiment_conf
        self.episodic_memory.store_episode(text, styled_response, accuracy=importance, emotion=dominant_emotion)
        narrative = self.self_narrative.generate_reasoning_narrative(text, importance, dominant_emotion)
        self.self_narrative.save_narrative(text, dominant_emotion, importance, narrative)

        # 10. 세션 메모리에 상호작용 기록
        self.session_memory.add_interaction(text, styled_response)

        # 11. 강화학습 에이전트에 피드백 제공 및 학습 수행 (정확히 연결)
        reward = sentiment_conf  # 실제로는 더 정교한 보상 설계 필요
        self.decision_engine.give_feedback(text, chosen_action, reward)

        return styled_response

    def chat(self):
        print("AI와 대화를 시작합니다. '종료'를 입력하면 종료됩니다.")
        while True:
            user_input = input("당신: ")
            if user_input.strip().lower() == "종료":
                print("AI: 안녕히 가세요!")
                break
            response = self.process_input(user_input)
            print(f"AI: {response}")

    def close(self):
        self.emotion_memory.close()
        self.episodic_memory.close()
        self.knowledge.close()
        self.bias.close()
        self.threat_detector.close()
        self.creativity.close()