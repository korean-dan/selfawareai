import argparse
from agent.self_model import SelfAwareAI

def run_ai(quiet: bool = False):
    ai = SelfAwareAI()
    try:
        if quiet:
            print("[모드: 조용히 실행] 내부 독백은 생략됩니다.")
            while True:
                user_input = input("당신: ")
                if user_input.strip().lower() == "종료":
                    print("AI: 안녕히 가세요!")
                    break
                response = ai.process_input(user_input)
                print(f"AI: {response}")
        else:
            ai.chat()
    except KeyboardInterrupt:
        print("\n[시스템 종료] 사용자에 의해 중단되었습니다.")
    finally:
        ai.close()
        print("[AI 종료] 감정, 기억, 사고 시스템을 안전하게 종료했습니다.")

def main():
    parser = argparse.ArgumentParser(description="자기인식형 AI CLI 실행기")
    parser.add_argument("--quiet", action="store_true", help="내부 독백 출력 생략")
    args = parser.parse_args()

    run_ai(quiet=args.quiet)

if __name__ == "__main__":
    main()