# FastAPI 웹 서버 인터페이스 최종 완성본
from fastapi import FastAPI
from pydantic import BaseModel
from agent.self_model import SelfAwareAI
import uvicorn

# AI 초기화
ai = SelfAwareAI()

# FastAPI 앱 초기화
app = FastAPI(title="자기인식형 AI 서비스", description="SelfAwareAI 웹 인터페이스", version="1.0")

# 사용자 입력 모델 정의
class UserInput(BaseModel):
    text: str

# 채팅 엔드포인트 정의 (비동기)
@app.post("/chat", summary="AI와 채팅", description="사용자 입력에 대한 AI의 응답을 반환합니다.")
async def chat(user_input: UserInput):
    response = ai.process_input(user_input.text)
    return {"response": response}

# 서버 종료 시 AI 리소스 안전하게 종료
@app.on_event("shutdown")
def shutdown_event():
    ai.close()