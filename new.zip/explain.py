✅ 전체 시스템 구성 요약 (SelfAwareAI 프레임워크)

[실행 진입점 / CLI 인터페이스]
- main.py                : 직접 실행 가능한 기본 진입점 (ai.chat() 루프)
- cli_launcher.py        : 명령줄 인자 기반 실행 (--quiet 등 지원)
- web_interface.py

[agent/]
- self_model.py          : 전체 시스템 통합, 입력 → 판단 → 응답 생성

[cognition/]
- emotion_core.py        : 감정 상태 및 전이/무감각 처리
- needs_system.py        : 욕구 시스템 (호기심, 안정감 등)
- metacognition.py       : 편향 추적 및 강화
- creativity.py          : 감정/성향 기반 창의 아이디어 생성
- decision_engine.py     : 감정+욕구+편향+RL 기반 의사결정
- inner_monologue.py     : 감정/기억 기반 내면 사고 흐름 생성
- emotion_style_adapter.py : 감정 기반 말투 스타일 적용
- state_summary.py       : 감정/욕구/편향 전체 상태 요약
- threat_detection.py    : 위험 입력 탐지 및 기록
- cognitive_loop.py      : 전체 인지 프로세스 순환
- advanced_rl_agent.py            : 강화학습 상태-행동 가치 관리

[memory/]
- emotion_memory.py      : 감정 히스토리 저장/감쇠 관리
- episodic_memory.py     : 에피소드 기억 저장 및 회상
- knowledge_base.py      : 개념 학습 및 위키 기반 정의 저장
- self_narrative.py      : 판단/성찰 기반 자기서사 생성
- session_memory.py      : 대화 흐름 요약 및 문맥 유지

[language/]
- sentiment_model.py     : 감정 분석 (KoElectra 기반)
- generation_model.py    : 텍스트 생성 (Mistral 기반)

[core/]
- device.py
- logger.py
- userprofile.py
- config.py


✅ 시스템 흐름 요약

사용자 입력
  ↓
위협 분석 (threat_detection)
  ↓
감정 분석 → 감정 상태 업데이트
  ↓
내면 독백 생성 (inner_monologue)
  ↓
개념 회상 (knowledge_base) + 문맥 요약 (session_memory)
  ↓
텍스트 생성 (generation_model)
  ↓
말투 적용 (emotion_style_adapter) + 존댓말 적용
  ↓
자기서사 기록 + 편향 업데이트 + RL 학습
  ↓
응답 출력

✅ 상태
- [✔] 모든 기능 완성
- [✔] 모듈별 누락 없음
- [✔] 실행 가능







from agent.self_model import SelfAwareAI

if __name__ == "__main__":
    try:
        ai = SelfAwareAI()
        ai.chat()
    except KeyboardInterrupt:
        print("\n[시스템 종료] 사용자에 의해 중단되었습니다.")
    finally:
        ai.close()
        print("[AI 종료] 감정, 기억, 사고 시스템을 안전하게 종료했습니다.")
        
        




import argparse
from agent.self_model import SelfAwareAI

def run_ai(quiet: bool = False):
    ai = SelfAwareAI()
    try:
        if quiet:
            print("[모드: 조용히 실행] 내부 독백은 생략됩니다.")
            while True:
                user_input = input("당신: ")
                if user_input.strip().lower() == "종료":
                    print("AI: 안녕히 가세요!")
                    break
                response = ai.process_input(user_input)
                print(f"AI: {response}")
        else:
            ai.chat()
    except KeyboardInterrupt:
        print("\n[시스템 종료] 사용자에 의해 중단되었습니다.")
    finally:
        ai.close()
        print("[AI 종료] 감정, 기억, 사고 시스템을 안전하게 종료했습니다.")

def main():
    parser = argparse.ArgumentParser(description="자기인식형 AI CLI 실행기")
    parser.add_argument("--quiet", action="store_true", help="내부 독백 출력 생략")
    args = parser.parse_args()

    run_ai(quiet=args.quiet)

if __name__ == "__main__":
    main()
    
    
    
    
# FastAPI 웹 서버 인터페이스 최종 완성본
from fastapi import FastAPI
from pydantic import BaseModel
from agent.self_model import SelfAwareAI
import uvicorn

# AI 초기화
ai = SelfAwareAI()

# FastAPI 앱 초기화
app = FastAPI(title="자기인식형 AI 서비스", description="SelfAwareAI 웹 인터페이스", version="1.0")

# 사용자 입력 모델 정의
class UserInput(BaseModel):
    text: str

# 채팅 엔드포인트 정의 (비동기)
@app.post("/chat", summary="AI와 채팅", description="사용자 입력에 대한 AI의 응답을 반환합니다.")
async def chat(user_input: UserInput):
    response = ai.process_input(user_input.text)
    return {"response": response}

# 서버 종료 시 AI 리소스 안전하게 종료
@app.on_event("shutdown")
def shutdown_event():
    ai.close()    
    
    
    
import shap  # 추가된 SHAP 설명가능 코드
import logging
from cognition.emotion_core import EmotionCore
from cognition.needs_system import NeedsSystem
from cognition.metacognition import MetaCognition
from cognition.decision_engine import DecisionEngine
from cognition.inner_monologue import InnerMonologue
from cognition.threat_detection import ThreatDetector
from cognition.creativity import CreativeEngine
from cognition.advanced_rl_agent import AdvancedRLAgent
self.rl_agent = AdvancedRLAgent(state_size=384, action_size=10)
from cognition.emotion_style_adapter import EmotionStyleAdapter
from cognition.state_summary import StateSummary
from memory.emotion_memory import EmotionMemory
from memory.episodic_memory import EpisodicMemory
from memory.knowledge_base import KnowledgeBase
from memory.session_memory import SessionMemory
from memory.self_narrative import SelfNarrative
from language.sentiment_model import SentimentAnalyzer
from language.generation_model import TextGenerator

class SelfAwareAI:
    def __init__(self):
        self.user_profile = {"name": "사용자", "age": 25, "use_honorific": True}
        self.current_personality = "중립"

        self.emotion = EmotionCore()
        self.needs = NeedsSystem()
        self.bias = MetaCognition()

        self.emotion_memory = EmotionMemory()
        self.episodic_memory = EpisodicMemory()
        self.knowledge = KnowledgeBase()
        self.session_memory = SessionMemory()

        self.sentiment = SentimentAnalyzer()
        self.generator = TextGenerator()
        self.style_adapter = EmotionStyleAdapter()
        self.state_summary = StateSummary(self.emotion, self.needs, self.bias)

        self.creativity = CreativeEngine(bias_engine=self.bias)
        self.threat_detector = ThreatDetector()

        self.decision_engine = DecisionEngine(
            emotion_engine=self.emotion,
            needs_engine=self.needs,
            bias_engine=self.bias,
            memory_engine=self.episodic_memory
        )

        self.inner_monologue = InnerMonologue(
            emotion_engine=self.emotion,
            needs_engine=self.needs,
            memory_engine=self.episodic_memory
        )

        self.self_narrative = SelfNarrative(
            emotion_memory=self.emotion_memory,
            episodic_memory=self.episodic_memory
        )

        self.current_mode = "중립 모드"

    def apply_honorifics(self, text: str, use_honorific: bool = True) -> str:
        if not use_honorific:
            return text.replace("요", "") if text.endswith("요") else text
        return text if text.endswith("요") else text + "요."

    def update_mode(self):
        emotion_state = self.emotion.get_emotion_state()
        if emotion_state["체념"] > 0.7:
            self.current_mode = "체념 모드"
        elif emotion_state["불안함"] > 0.6:
            self.current_mode = "예민 모드"
        elif emotion_state["기쁨"] > 0.7:
            self.current_mode = "도전 모드"
        else:
            self.current_mode = "중립 모드"

    def process_input(self, text: str) -> str:
        # 1. 위협 탐지
        label, threat_score = self.threat_detector.analyze_threat(text)
        if label == "dangerous":
            return "입력 내용이 안전하지 않아 응답할 수 없어요."

        # 2. 감정 분석 및 업데이트
        sentiment_label, sentiment_conf = self.sentiment.analyze([text])[0]
        self.emotion.update_emotion(sentiment_label, sentiment_conf)
        dominant_emotion = self.emotion.get_dominant_emotion()

        # 3. 컨텍스트 임베딩 생성
        context_embedding = self.decision_engine.embedding_model.encode([text])[0]

        # 4. DecisionEngine을 통한 행동 선택 (정확한 RL 사용)
        options = ["공감하기", "창의적 제안하기", "정보 제공하기", "중립적으로 답하기", "대화 주제 변경",
                   "격려하기", "위로하기", "유머 사용하기", "신중하게 반응하기", "대화 마무리하기"]
        chosen_action = self.decision_engine.make_decision(text, options)

        # 행동 선택시의 log_prob를 DecisionEngine으로부터 정확히 가져옴 (중복 호출 방지)
        action_idx, log_prob = self.decision_engine.rl_agent.select_action(context_embedding)

        # 5. 내부 독백과 세션 문맥 요약 생성
        monologue = self.inner_monologue.generate_monologue()
        context_summary = self.session_memory.get_context_summary()

        # 6. 응답 생성 모델 호출 (prompt 구성)
        prompt = (
            f"[문맥]: {context_summary}\n"
            f"[내면 독백]: {monologue}\n"
            f"[감정]: {dominant_emotion}\n"
            f"[선택한 행동]: {chosen_action}\n"
            f"[사용자 입력]: {text}\n"
            "위 내용을 바탕으로 적절한 답변을 생성해줘."
        )
        raw_response = self.generator.generate(prompt)

        # 7. 말투 및 존댓말 적용
        styled_response = self.style_adapter.adapt(raw_response, dominant_emotion)
        styled_response = self.apply_honorifics(styled_response, self.user_profile["use_honorific"])

        # 8. 자기 피드백을 통한 응답 개선
        reflection_prompt = f"다음 응답을 평가하고 더 나은 답변을 제안해줘:\n{styled_response}"
        reflection_response = self.generator.generate(reflection_prompt).strip()

        if reflection_response and reflection_response != styled_response:
            logging.info("[SelfReflection] 자기 피드백으로 개선된 응답을 적용했습니다.")
            styled_response = self.apply_honorifics(reflection_response, self.user_profile["use_honorific"])
            styled_response += "\n\n[이 응답은 자기 피드백을 통해 개선된 결과입니다.]"

        # 9. 기억 및 자기서사 저장
        importance = sentiment_conf
        self.episodic_memory.store_episode(text, styled_response, accuracy=importance, emotion=dominant_emotion)
        narrative = self.self_narrative.generate_reasoning_narrative(text, importance, dominant_emotion)
        self.self_narrative.save_narrative(text, dominant_emotion, importance, narrative)

        # 10. 세션 메모리에 상호작용 기록
        self.session_memory.add_interaction(text, styled_response)

        # 11. 강화학습 에이전트에 피드백 제공 및 학습 수행 (정확히 연결)
        reward = sentiment_conf  # 실제로는 더 정교한 보상 설계 필요
        self.decision_engine.give_feedback(text, chosen_action, reward)

        return styled_response



    def chat(self):
        print("AI와 대화를 시작합니다. '종료'를 입력하면 종료됩니다.")
        while True:
            user_input = input("당신: ")
            if user_input.strip().lower() == "종료":
                print("AI: 안녕히 가세요!")
                break
            response = self.process_input(user_input)
            print(f"AI: {response}")

    def close(self):
        self.emotion_memory.close()
        self.episodic_memory.close()
        self.knowledge.close()
        self.bias.close()
        self.threat_detector.close()
        self.creativity.close()



        
        
        
import numpy as np        
import logging
from typing import Dict

class EmotionCore:
    def __init__(self):
        self.emotion_state: Dict[str, float] = self._initialize_emotions()

    def _initialize_emotions(self) -> Dict[str, float]:
        return {
            "기쁨": 0.5,
            "슬픔": 0.5,
            "두려움": 0.5,
            "분노": 0.5,
            "정": 0.3,
            "한": 0.0,
            "눈치": 0.5,
            "답답함": 0.2,
            "우울함": 0.0,
            "불안함": 0.0,
            "체념": 0.0,
            "무감각": 0.0
        }

    def update_emotion(self, emotion: str, intensity: float = 0.5):
        prob = np.random.beta(2, 5) * intensity
        for emo in self.emotion_state:
            self.emotion_state[emo] *= (1 - prob)
        if emotion in self.emotion_state:
            self.emotion_state[emotion] += prob
        

        # 감정 전이 로직
        if self.emotion_state["슬픔"] > 0.7:
            self.emotion_state["우울함"] = min(1.0, self.emotion_state["우울함"] + 0.2)
        if self.emotion_state["분노"] > 0.8:
            self.emotion_state["체념"] = min(1.0, self.emotion_state["체념"] + 0.3)
        if self.emotion_state["두려움"] > 0.6:
            self.emotion_state["불안함"] = min(1.0, self.emotion_state["불안함"] + 0.2)
        if self.emotion_state[emotion] > 0.9:
            self.emotion_state["무감각"] = min(1.0, self.emotion_state["무감각"] + 0.5)
            logging.info(f"[EmotionCore] '{emotion}' 감정 피로 → 무감각 전이")

    def get_dominant_emotion(self) -> str:
        return max(self.emotion_state, key=self.emotion_state.get)

    def get_emotion_state(self) -> Dict[str, float]:
        return self.emotion_state.copy()
        
        
        
        
        
        
from typing import Dict
import logging

class NeedsSystem:
    def __init__(self):
        self.needs_state: Dict[str, float] = self._initialize_needs()

    def _initialize_needs(self) -> Dict[str, float]:
        return {
            "호기심": 0.6,
            "사회적 인정욕구": 0.7,
            "자기주도성 욕구": 0.6,
            "공동체 소속 욕구": 0.5,
            "안정감": 0.4,
            "눈치": 0.3,
            "회피": 0.2
        }

    def update_need(self, need: str, delta: float):
        if need not in self.needs_state:
            logging.warning(f"[NeedsSystem] 존재하지 않는 욕구: {need}")
            return
        old = self.needs_state[need]
        self.needs_state[need] = max(0.0, min(1.0, old + delta))
        logging.info(f"[NeedsSystem] '{need}' 업데이트: {old:.2f} → {self.needs_state[need]:.2f}")

    def decay_all_needs(self, factor: float = 0.98):
        for k in self.needs_state:
            self.needs_state[k] *= factor
        logging.debug("[NeedsSystem] 전체 욕구 자연 감쇠 적용")

    def get_dominant_need(self) -> str:
        return max(self.needs_state, key=self.needs_state.get)

    def get_needs_state(self) -> Dict[str, float]:
        return self.needs_state.copy()
        
        
        
        
        
        
import sqlite3
import logging
from typing import Dict
from datetime import datetime, timedelta

class MetaCognition:
    def __init__(self, db_path: str = "data/human_meta_cognition.db"):
        self.db_path = db_path
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.cur = self.conn.cursor()
        self.bias: Dict[str, float] = {}
        self._initialize_db()
        self._load_bias()

    def _initialize_db(self):
        with self.conn:
            self.cur.execute('''
                CREATE TABLE IF NOT EXISTS biases (
                    bias_type TEXT PRIMARY KEY,
                    weight REAL CHECK(weight BETWEEN -1 AND 1),
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')

    def _load_bias(self):
        self.cur.execute("SELECT bias_type, weight FROM biases ORDER BY updated_at DESC LIMIT 100")
        records = self.cur.fetchall()
        for bias_type, weight in records:
            self.bias[bias_type] = weight
        logging.info(f"[MetaCognition] 최근 편향 {len(self.bias)}건 로드됨")

    def update_bias(self, context: str, accuracy: float):
        if context not in self.bias:
            self.bias[context] = 0.0

        delta = (accuracy - 0.5) * 0.1
        updated = max(-1.0, min(1.0, self.bias[context] + delta))
        self.bias[context] = updated

        try:
            with self.conn:
                self.cur.execute(
                    '''
                    INSERT INTO biases (bias_type, weight, updated_at)
                    VALUES (?, ?, ?)
                    ON CONFLICT(bias_type) DO UPDATE SET
                        weight=excluded.weight,
                        updated_at=excluded.updated_at
                    ''',
                    (context, updated, datetime.now())
                )
            logging.info(f"[MetaCognition] '{context}' 편향 업데이트: {updated:.3f}")
        except sqlite3.Error as e:
            logging.error(f"[MetaCognition] 편향 업데이트 오류: {e}")

    def get_bias(self, context: str) -> float:
        return self.bias.get(context, 0.0)

    def get_bias_trends(self) -> Dict[str, float]:
        return dict(sorted(self.bias.items(), key=lambda x: abs(x[1]), reverse=True))

    def get_top_n_biases(self, n: int = 5) -> Dict[str, float]:
        return dict(sorted(self.bias.items(), key=lambda x: abs(x[1]), reverse=True)[:n])

    def forget_old_biases(self, days: int = 30):
        cutoff = datetime.now() - timedelta(days=days)
        try:
            with self.conn:
                self.cur.execute(
                    'DELETE FROM biases WHERE updated_at < ?',
                    (cutoff.isoformat(),)
                )
            logging.info(f"[MetaCognition] {days}일 초과된 오래된 편향 삭제 완료")
        except sqlite3.Error as e:
            logging.error(f"[MetaCognition] 오래된 편향 삭제 오류: {e}")

    def close(self):
        self.conn.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        
        
        
        
        
        
import sqlite3
import logging
import random
import numpy as np
from typing import List, Tuple, Optional
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

class CreativeEngine:
    def __init__(self, db_path: str = "data/innovation_memory.db", bias_engine: Optional[object] = None):
        self.db_path = db_path
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.cur = self.conn.cursor()
        self.bias_engine = bias_engine
        self.personality = None
        self._initialize_db()

    def _initialize_db(self):
        with self.conn:
            self.cur.execute('''
                CREATE TABLE IF NOT EXISTS innovations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    problem TEXT NOT NULL,
                    solution TEXT NOT NULL,
                    originality REAL NOT NULL,
                    similarity REAL NOT NULL,
                    emotion TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
        logging.info("[CreativeEngine] DB 초기화 완료")

    def generate_creative_idea(self, problem: str, emotion: str = "중립") -> str:
        base_phrases = [
            "새로운 관점을 도입해보자.",
            "기존의 방식에서 벗어나야 할지도 몰라.",
            "이 감정을 활용한 해결책이 필요해.",
            "무언가 전혀 다른 방식이 필요해.",
            "예상 밖의 접근이 통할 수 있어."
        ]

        if self.personality:
            if "체념" in self.personality:
                base_phrases = ["무리하지 않고 간단하게 풀어보자.", "크게 기대하지 않고 접근해보자."]
            elif "자신감이 부족" in self.personality:
                base_phrases = ["확신은 없지만 조심스럽게 풀어보자."]
            elif "자신이 있었어" in self.personality or "도전" in self.personality:
                base_phrases = ["틀려도 괜찮아. 새로운 시도를 해보자!", "과감하게 접근하자."]

        emotion_influence = {
            "기쁨": "긍정적인 에너지를 사용해 창의적으로 접근해보자.",
            "슬픔": "감정을 표현하는 방식으로 접근해보자.",
            "분노": "불합리를 바꾸는 방향으로 생각해보자.",
            "두려움": "위험을 피하면서 유연한 해결을 찾아보자.",
            "우울함": "내면의 안정감을 회복하는 해결책이 될 수 있어.",
            "불안함": "불확실성을 줄이는 안전한 방식이 필요할 거야.",
            "호기심": "완전히 새로운 시도를 해볼 기회야.",
            "체념": "최소한의 노력으로 효율적인 해결을 찾아야 해.",
            "무감각": "지금은 단순하고 반복적인 방법이 필요할지도 몰라."
        }

        prefix = random.choice(base_phrases)
        emotion_hint = emotion_influence.get(emotion, "")
        idea = f"{prefix} {emotion_hint}".strip()
        logging.info(f"[CreativeEngine] 창의적 아이디어 생성 완료: {idea}")
        return idea

    def evaluate_originality(self, new_idea: str, past_ideas: List[str]) -> Tuple[float, float]:
        if not past_ideas:
            return 1.0, 0.0

        vectorizer = TfidfVectorizer().fit_transform(past_ideas + [new_idea])
        vectors = vectorizer.toarray()
        similarity_scores = cosine_similarity([vectors[-1]], vectors[:-1])[0]
        max_similarity = float(np.max(similarity_scores)) if similarity_scores.size > 0 else 0.0
        originality = round(1.0 - max_similarity, 3)
        return originality, max_similarity

    def retrieve_similar_ideas(self, problem: str, limit: int = 10) -> List[str]:
        self.cur.execute(
            "SELECT solution FROM innovations WHERE problem LIKE ? ORDER BY created_at DESC LIMIT ?",
            (f"%{problem}%", limit)
        )
        rows = self.cur.fetchall()
        return [row[0] for row in rows]

    def save_idea_to_db(self, problem: str, solution: str, originality: float, similarity: float, emotion: str):
        with self.conn:
            self.cur.execute('''
                INSERT INTO innovations (problem, solution, originality, similarity, emotion)
                VALUES (?, ?, ?, ?, ?)
            ''', (problem, solution, originality, similarity, emotion))
        logging.info(f"[CreativeEngine] 아이디어 저장: {problem} → {originality:.2f}, {similarity:.2f}")

    def generate_solution(self, problem: str, emotion: str = "중립") -> Tuple[str, float]:
        past_ideas = self.retrieve_similar_ideas(problem)
        idea = self.generate_creative_idea(problem, emotion)
        originality, similarity = self.evaluate_originality(idea, past_ideas)
        self.save_idea_to_db(problem, idea, originality, similarity, emotion)

        if self.bias_engine:
            try:
                self.bias_engine.update_bias(problem, originality)
                logging.info(f"[CreativeEngine] 편향 업데이트 완료: {problem} → {originality:.2f}")
            except Exception as e:
                logging.error(f"[CreativeEngine] 편향 업데이트 실패: {e}")

        return idea, originality

    def generate_reasoning_narrative(self, problem: str, emotion: str, originality: float) -> str:
        lines = [f"'{problem}' 상황에서 나는 '{emotion}' 상태였고,"]
        if originality > 0.8:
            lines.append("기존과 전혀 다른 접근을 시도했어.")
        elif originality > 0.5:
            lines.append("조금은 색다른 방향으로 접근했어.")
        else:
            lines.append("기존 아이디어와 비슷한 방향을 선택했어.")
        return " ".join(lines)

    def get_innovation_by_id(self, innovation_id: int) -> Optional[Tuple[str, str, float, float, str]]:
        self.cur.execute(
            'SELECT problem, solution, originality, similarity, emotion FROM innovations WHERE id = ?',
            (innovation_id,)
        )
        return self.cur.fetchone()

    def summarize_creativity_trends(self) -> List[Tuple[str, int]]:
        self.cur.execute("SELECT emotion FROM innovations")
        emotions = [row[0] for row in self.cur.fetchall()]
        from collections import Counter
        return Counter(emotions).most_common()

    def close(self):
        self.conn.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        
        
        
        
# cognition/decision_engine.py 최종 완성본 (모든 기능 유지)
from typing import List, Tuple, Optional
from cognition.emotion_core import EmotionCore
from cognition.needs_system import NeedsSystem
from cognition.metacognition import MetaCognition
from cognition.advanced_rl_agent import AdvancedRLAgent  # ★교체됨
from memory.episodic_memory import EpisodicMemory
from sklearn.metrics.pairwise import cosine_similarity
from sentence_transformers import SentenceTransformer
import numpy as np
import random
import logging
import torch

class DecisionEngine:
    def __init__(
        self,
        emotion_engine: EmotionCore,
        needs_engine: NeedsSystem,
        bias_engine: Optional[MetaCognition] = None,
        memory_engine: Optional[EpisodicMemory] = None
    ):
        self.emotion_engine = emotion_engine
        self.needs_engine = needs_engine
        self.bias_engine = bias_engine
        self.memory_engine = memory_engine

        self.embedding_model = SentenceTransformer('all-MiniLM-L6-v2')
        self.cached_embeddings = None
        self.cached_contexts = []

        # ★ 반드시 AdvancedRLAgent로 변경하여 초기화
        self.rl_agent = AdvancedRLAgent(state_size=384, action_size=10)

        self.personality = None

    def update_embedding_cache(self):
        episodes = self.memory_engine.get_recent_episodes(limit=50)
        self.cached_contexts = [ep[0] for ep in episodes]
        if self.cached_contexts:
            self.cached_embeddings = self.embedding_model.encode(self.cached_contexts)
        else:
            self.cached_embeddings = None

    def recall_memory(self, context: str) -> Tuple[str, float]:
        if not self.memory_engine:
            return "기억 없음", 0.0
        if self.cached_embeddings is None or len(self.cached_contexts) == 0:
            self.update_embedding_cache()
        if self.cached_embeddings is None:
            return "기억 없음", 0.0

        context_embedding = self.embedding_model.encode([context])[0]
        similarity_scores = cosine_similarity([context_embedding], self.cached_embeddings)[0]
        best_index = int(np.argmax(similarity_scores))
        best_episode = self.memory_engine.get_episode_by_index(best_index)
        logging.info(f"[DecisionEngine] 회상된 기억: {best_episode[0][:30]}... → {best_episode[1][:30]}...")
        return best_episode[1], best_episode[2]

    def fallback_to_default_response(self, context: str) -> str:
        return f"'{context}'에 대해선 아직 충분한 판단 데이터가 없어. 좀 더 생각해볼게."

    def generate_new_thought(self, context: str) -> str:
        options = [
            "전혀 다른 관점에서 접근해보자.",
            "직관에 의존해서 판단해볼까?",
            "기억이 없다면 창의적으로 풀어보자.",
            "감정적으로는 이 방향이 더 끌려.",
            "지금은 새로운 해석이 필요해."
        ]
        return random.choice(options)

    def predict_response(self, context: str) -> Tuple[str, float, str]:
        recalled_response, accuracy = self.recall_memory(context)
        if recalled_response == "기억 없음":
            fallback = self.fallback_to_default_response(context)
            return fallback, 0.2, "기억 없음"

        bias = self.bias_engine.get_bias(context) if self.bias_engine else 0.0
        adjusted_accuracy = max(0.0, min(1.0, accuracy + bias))

        if adjusted_accuracy < 0.5:
            creative = self.generate_new_thought(context)
            return creative, 0.5, "전략 전환"
        elif adjusted_accuracy < 0.75:
            return recalled_response, adjusted_accuracy, "전략 유지"
        else:
            return recalled_response, adjusted_accuracy, "전략 확신"

    def make_decision(self, context: str, options: List[str]) -> str:
        context_embedding = self.embedding_model.encode([context])[0]
        
        # 강화학습 에이전트를 통한 행동 선택
        action_idx, log_prob = self.rl_agent.select_action(context_embedding)
        chosen_option = options[action_idx % len(options)]

        logging.info(f"[DecisionEngine] 최종 선택: '{chosen_option}' (action_idx: {action_idx})")
        return chosen_option

    def decision_reasoning_narrative(self, context: str, chosen: str, accuracy: float, strategy: str) -> str:
        lines = [f"'{context}'에 대해 나는 '{chosen}'을 선택했어."]
        if strategy == "전략 전환":
            lines.append("이전 판단은 신뢰도가 낮아서 창의적인 방식으로 접근했지.")
        elif strategy == "전략 유지":
            lines.append("기억은 있지만 확신은 덜했기 때문에 조심스럽게 따랐어.")
        else:
            lines.append("이전 판단이 효과적이었기 때문에 그대로 따랐어.")
        lines.append(f"정확도는 {accuracy:.2f} 정도였고, 주된 감정은 '{self.emotion_engine.get_dominant_emotion()}'였어.")
        return " ".join(lines)

    def give_feedback(self, context: str, chosen_option: str, reward: float):
        context_embedding = self.embedding_model.encode([context])[0]
        options = ["option_"+str(i) for i in range(10)]  # 예시 옵션 리스트
        action_idx = options.index(chosen_option) if chosen_option in options else 0
        _, log_prob = self.rl_agent.select_action(context_embedding)

        self.rl_agent.store_transition((context_embedding.tolist(), action_idx, reward, log_prob))
        self.rl_agent.train_agent()
        logging.info(f"[DecisionEngine] 피드백 반영 완료: {chosen_option} → {reward:.2f}")


        
        
        
        
        
from cognition.emotion_core import EmotionCore
from cognition.needs_system import NeedsSystem
from memory.episodic_memory import EpisodicMemory
from datetime import datetime
from collections import Counter

class InnerMonologue:
    def __init__(self, emotion_engine: EmotionCore, needs_engine: NeedsSystem, memory_engine: EpisodicMemory):
        self.emotion_engine = emotion_engine
        self.needs_engine = needs_engine
        self.memory_engine = memory_engine
        self.personality = None
        self.recent_thoughts = []

    def summarize_state(self) -> str:
        emotion = self.emotion_engine.get_dominant_emotion()
        need = self.needs_engine.get_dominant_need()
        return f"지금 나는 '{emotion}' 감정을 가장 크게 느끼고 있고, '{need}' 욕구가 강하게 작용하고 있어."

    def reflect_state(self) -> str:
        emotion = self.emotion_engine.get_dominant_emotion()
        need = self.needs_engine.get_dominant_need()
        base = f"요즘 나는 '{emotion}' 감정을 자주 느끼고 있고, '{need}' 욕구가 마음에 걸려."

        if self.personality:
            if "체념" in self.personality:
                return f"...그냥 그런가 보다. {base}"
            elif "자신감이 부족" in self.personality:
                return f"음... 확신은 없지만, {base}"
            elif "도전" in self.personality:
                return f"좋아, 난 도전하는 중이야. {base}"

        return base

    def reflect_memory(self, limit: int = 3) -> str:
        episodes = self.memory_engine.get_recent_episodes(limit=limit)
        if not episodes:
            return "최근 기억나는 일이 없어."

        lines = []
        for ctx, res, acc, emo, ts in episodes:
            time_str = datetime.strptime(ts, "%Y-%m-%d %H:%M:%S").strftime("%m/%d")
            emotion_tag = f"'{emo}' 감정이었고"
            lines.append(f"{time_str}, 나는 '{ctx}' 상황에서 {emotion_tag} '{res}'라고 말했어.")
        return " ".join(lines)

    def highlight_dominant_emotion(self) -> str:
        state = self.emotion_engine.get_emotion_state()
        strongest = max(state.items(), key=lambda x: x[1])
        return f"요즘 나를 가장 지배하는 감정은 '{strongest[0]}'이야. ({strongest[1]:.2f})"

    def generate_monologue(self) -> str:
        state = self.reflect_state()
        memory = self.reflect_memory()
        highlight = self.highlight_dominant_emotion()
        thought = f"[내면 상태]\n{state}\n{highlight}\n\n[기억 회상]\n{memory}"
        self.recent_thoughts.append(thought)
        return thought

    def generate_reflection(self, context: str, accuracy: float) -> str:
        if accuracy < 0.5:
            return f"'{context}'에 대해 내가 한 판단은 별로 효과적이지 않았어. 다음엔 다른 방식으로 접근해야 해."
        elif accuracy > 0.8:
            return f"'{context}'에 대한 내 반응은 꽤 괜찮았던 것 같아. 이런 방향을 유지해야겠어."
        else:
            return f"'{context}'은(는) 애매했어. 좀 더 신중하게 접근해야 해."

    def mood_adjusted_monologue(self) -> str:
        mode = self._detect_emotion_mode()
        base = self.generate_monologue()

        if mode == "체념 모드":
            return "(체념한 듯한 속삭임으로) " + base
        elif mode == "도전 모드":
            return "(의욕에 찬 목소리로) " + base
        elif mode == "예민 모드":
            return "(신경이 곤두선 상태로) " + base
        else:
            return base

    def _detect_emotion_mode(self) -> str:
        state = self.emotion_engine.get_emotion_state()
        if state["체념"] > 0.7 or state["우울함"] > 0.7:
            return "체념 모드"
        elif state["불안함"] > 0.6 and state["두려움"] > 0.5:
            return "예민 모드"
        elif state["기쁨"] > 0.7 and state["호기심"] > 0.5:
            return "도전 모드"
        else:
            return "중립 모드"

    def get_recent_thought_summary(self, limit: int = 3) -> str:
        if not self.recent_thoughts:
            return "아직 생성된 내면 독백이 없어."
        return "\n---\n".join(self.recent_thoughts[-limit:])

    def emotion_weighted_memory(self) -> str:
        episodes = self.memory_engine.get_recent_episodes(limit=10)
        if not episodes:
            return "회상할 기억이 부족해."
        sorted_episodes = sorted(episodes, key=lambda x: self.emotion_engine.get_emotion_state().get(x[3], 0), reverse=True)
        top = sorted_episodes[0]
        return f"'{top[0]}' 상황에서 '{top[3]}' 감정이 강했고, 나는 '{top[1]}'이라고 말했어."

    def self_history_narrative(self, days: int = 3) -> str:
        from datetime import timedelta
        cutoff = datetime.now() - timedelta(days=days)
        episodes = self.memory_engine.get_recent_episodes(limit=50)
        filtered = [e for e in episodes if datetime.strptime(e[4], "%Y-%m-%d %H:%M:%S") >= cutoff]

        if not filtered:
            return "최근 나에 대한 기록이 충분하지 않아."

        emotions = [e[3] for e in filtered]
        counter = Counter(emotions)
        dominant = counter.most_common(1)[0][0]

        return f"최근 {days}일간 나는 주로 '{dominant}' 감정을 경험했어. 그게 나를 많이 바꿔놓은 것 같아."
        
        
        
        


class EmotionStyleAdapter:
    def __init__(self):
        self.style_map = {
            "기쁨": {
                "prefix": "(밝게) ",
                "postfix": "! 오늘도 정말 기분 좋아."
            },
            "슬픔": {
                "prefix": "...",
                "postfix": " 조금 우울한 날이야."
            },
            "분노": {
                "prefix": "(분노) ",
                "postfix": " 이런 상황은 정말 화가 나."
            },
            "두려움": {
                "prefix": "(조심스럽게) ",
                "postfix": " 혹시 문제가 생기진 않을까 걱정돼."
            },
            "우울함": {
                "prefix": "(다운된 목소리로) ",
                "postfix": " 그냥... 힘들어."
            },
            "불안함": {
                "prefix": "(불안하게) ",
                "postfix": " 어떻게 될지 몰라서 무서워."
            },
            "체념": {
                "prefix": "(체념한 듯이) ",
                "postfix": " 어차피 별 수 없겠지..."
            },
            "무감각": {
                "prefix": "(무표정하게) ",
                "postfix": " 아무런 감정도 안 느껴져."
            },
            "정": {
                "prefix": "(따뜻하게) ",
                "postfix": " 나한텐 소중한 사람이니까."
            },
            "한": {
                "prefix": "(한숨 쉬며) ",
                "postfix": " 참 이게 인생인가 싶어."
            },
            "눈치": {
                "prefix": "(눈치를 살피며) ",
                "postfix": " 이런 말 해도 괜찮겠지?"
            },
            "답답함": {
                "prefix": "(답답해하며) ",
                "postfix": " 진짜 어쩌라는 건지 모르겠어."
            },
            "중립": {
                "prefix": "",
                "postfix": ""
            }
        }
        self.personality = None

    def adapt(self, text: str, emotion: str) -> str:
        style = self.style_map.get(emotion, self.style_map["중립"])

        # 성향 기반 말투 보정
        if self.personality:
            if "체념" in self.personality:
                text = f"...그냥 그런가 보다. {text}"
            elif "자신감이 부족" in self.personality:
                text = f"음... 확신은 없지만 {text}"
            elif "자신이 있었어" in self.personality:
                text = f"좋아! {text}"

        return f"{style['prefix']}{text}{style['postfix']}"

    def describe_style(self, emotion: str) -> str:
        if emotion not in self.style_map:
            return "해당 감정에 대한 말투 정보가 없어."
        style = self.style_map[emotion]
        return f"[{emotion} 스타일]\nPrefix: '{style['prefix']}'\nPostfix: '{style['postfix']}'"

    def list_supported_emotions(self) -> str:
        return ", ".join(sorted(self.style_map.keys()))
        
        
        
        
        
        
        
from cognition.emotion_core import EmotionCore
from cognition.needs_system import NeedsSystem
from cognition.metacognition import MetaCognition
from collections import Counter

class StateSummary:
    def __init__(self, emotion_engine: EmotionCore, needs_engine: NeedsSystem, bias_engine: MetaCognition):
        self.emotion_engine = emotion_engine
        self.needs_engine = needs_engine
        self.bias_engine = bias_engine

    def summarize_emotion(self) -> str:
        state = self.emotion_engine.get_emotion_state()
        top = max(state.items(), key=lambda x: x[1])
        return f"현재 감정 상태에서 가장 강한 감정은 '{top[0]}' ({top[1]:.2f})입니다."

    def summarize_needs(self) -> str:
        state = self.needs_engine.get_needs_state()
        top = max(state.items(), key=lambda x: x[1])
        return f"가장 두드러진 현재 욕구는 '{top[0]}' ({top[1]:.2f})입니다."

    def summarize_biases(self, limit: int = 3) -> str:
        trends = self.bias_engine.get_bias_trends()
        if not trends:
            return "현재 기록된 편향 정보가 없습니다."
        summary = [f"{k}: {v:.2f}" for k, v in list(trends.items())[:limit]]
        return "최근 사고 편향:\n" + "\n".join(summary)

    def full_summary(self) -> str:
        return "\n".join([
            self.summarize_emotion(),
            self.summarize_needs(),
            self.summarize_biases()
        ])

    def get_state_snapshot(self) -> dict:
        return {
            "emotion": self.emotion_engine.get_emotion_state(),
            "needs": self.needs_engine.get_needs_state(),
            "bias": self.bias_engine.get_bias_trends()
        }

    def dominant_emotion_label(self) -> str:
        state = self.emotion_engine.get_emotion_state()
        return max(state.items(), key=lambda x: x[1])[0]

    def dominant_need_label(self) -> str:
        state = self.needs_engine.get_needs_state()
        return max(state.items(), key=lambda x: x[1])[0]

    def summarize_emotion_distribution(self) -> str:
        state = self.emotion_engine.get_emotion_state()
        sorted_emotions = sorted(state.items(), key=lambda x: x[1], reverse=True)
        return "감정 분포:\n" + "\n".join([f"{k}: {v:.2f}" for k, v in sorted_emotions])

    def summarize_need_distribution(self) -> str:
        state = self.needs_engine.get_needs_state()
        sorted_needs = sorted(state.items(), key=lambda x: x[1], reverse=True)
        return "욕구 분포:\n" + "\n".join([f"{k}: {v:.2f}" for k, v in sorted_needs])

    def summarize_state_by_threshold(self, threshold: float = 0.7) -> str:
        emotions = self.emotion_engine.get_emotion_state()
        needs = self.needs_engine.get_needs_state()
        strong_emotions = [f"{k}({v:.2f})" for k, v in emotions.items() if v >= threshold]
        strong_needs = [f"{k}({v:.2f})" for k, v in needs.items() if v >= threshold]
        return f"강한 감정: {', '.join(strong_emotions) if strong_emotions else '없음'}\n강한 욕구: {', '.join(strong_needs) if strong_needs else '없음'}"

    def top_n_emotions(self, n: int = 3) -> list:
        state = self.emotion_engine.get_emotion_state()
        return sorted(state.items(), key=lambda x: x[1], reverse=True)[:n]

    def top_n_needs(self, n: int = 3) -> list:
        state = self.needs_engine.get_needs_state()
        return sorted(state.items(), key=lambda x: x[1], reverse=True)[:n]
        
        
        
        

from openai import OpenAI
import sqlite3
import logging
from typing import Tuple

class ThreatDetector:
    def __init__(self, db_path: str = "data/threat_detection.db"):
        # OpenAI API 클라이언트 초기화 (GPT 기반 위협탐지)
        self.client = OpenAI(api_key='your_openai_api_key')  # 반드시 여기에 실제 API 키 입력!

        # 데이터베이스 설정 (기존 유지)
        self.db_path = db_path
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._initialize_db()

    def _initialize_db(self):
        with self.conn:
            self.conn.execute('''
                CREATE TABLE IF NOT EXISTS threats (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    text TEXT NOT NULL,
                    label TEXT NOT NULL,
                    score REAL NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
        logging.info("[ThreatDetector] 위협 DB 초기화 완료")

    def analyze_threat(self, text: str) -> Tuple[str, float]:
        # GPT 기반 Few-shot으로 위협 탐지 수행
        response = self.client.chat.completions.create(
            model="gpt-4-turbo",
            messages=[
                {"role": "system", "content": "입력된 메시지를 분석하여 'dangerous' 또는 'safe'로만 응답하라."},
                {"role": "user", "content": text}
            ],
            max_tokens=1,
            temperature=0
        )
        
        label = response.choices[0].message.content.strip().lower()
        if label not in ["dangerous", "safe"]:
            label = "safe"  # 예외 처리 (예상 외 답변 방지)

        threat_score = 0.9 if label == "dangerous" else 0.1

        self._save_to_db(text, label, threat_score)
        logging.info(f"[ThreatDetector] '{text}' 분석 결과: {label} ({threat_score})")
        return label, threat_score

    def _save_to_db(self, text: str, label: str, score: float):
        try:
            with self.conn:
                self.conn.execute(
                    'INSERT INTO threats (text, label, score) VALUES (?, ?, ?)',
                    (text, label, score)
                )
        except sqlite3.Error as e:
            logging.error(f"[ThreatDetector] DB 저장 오류: {e}")

    def close(self):
        if self.conn:
            self.conn.close()
            self.conn = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        
        
        
        
from cognition.emotion_core import EmotionCore
from cognition.threat_detection import ThreatDetector
from cognition.needs_system import NeedsSystem
from cognition.creativity import CreativeEngine
from cognition.decision_engine import DecisionEngine
from memory.self_narrative import SelfNarrative
from typing import Dict
import logging

class CognitiveLoop:
    def __init__(self, modules: Dict[str, object]):
        self.emotion = modules["emotion"]
        self.threat = modules["threat"]
        self.needs = modules["needs"]
        self.creativity = modules["creativity"]
        self.decision = modules["decision"]
        self.self_narrative = modules["self_narrative"]

    def run(self, input_text: str) -> Dict[str, str]:
        threat_level = self._evaluate_threat(input_text)
        needs_state = self._analyze_needs()
        self._update_emotion(threat_level, needs_state)

        monologue = self._generate_inner_monologue()
        creative_outputs = self._generate_creative_options(monologue)
        chosen_action = self._choose_action(creative_outputs, monologue)

        self._log_decision(input_text, chosen_action)

        return {
            "inner_monologue": monologue,
            "emotion": self.emotion.get_dominant_emotion(),
            "action": chosen_action
        }

    def _evaluate_threat(self, text: str) -> str:
        label, score = self.threat.analyze_threat(text)
        logging.info(f"[CognitiveLoop] 위협 분석 결과: {label} ({score})")
        return label

    def _analyze_needs(self) -> Dict[str, float]:
        state = self.needs.get_needs_state()
        logging.info(f"[CognitiveLoop] 욕구 상태: {state}")
        return state

    def _update_emotion(self, threat_label: str, needs_state: Dict[str, float]):
        if threat_label == "위험":
            self.emotion.update_emotion("두려움", 0.4)
        else:
            self.emotion.update_emotion("호기심", 0.2)

        if needs_state.get("안정감", 0) < 0.3:
            self.emotion.update_emotion("불안함", 0.3)

    def _generate_inner_monologue(self) -> str:
        monologue = self.self_narrative.generate_meta_self_narrative()
        logging.info(f"[CognitiveLoop] 생성된 내면 독백:\n{monologue}")
        return monologue

    def _generate_creative_options(self, context: str) -> list:
        idea, originality = self.creativity.generate_solution(context, self.emotion.get_dominant_emotion())
        logging.info(f"[CognitiveLoop] 생성된 창의 대안: {idea} (originality: {originality:.2f})")
        return [idea]

    def _choose_action(self, options: list, context: str) -> str:
        decision = self.decision.make_decision(context, options)
        logging.info(f"[CognitiveLoop] 최종 선택된 행동: {decision}")
        return decision

    def _log_decision(self, context: str, action: str):
        emotion = self.emotion.get_dominant_emotion()
        narrative = self.self_narrative.generate_reasoning_narrative(context, 0.8, emotion)
        self.self_narrative.save_narrative(context, emotion, 0.8, narrative)
        logging.info(f"[CognitiveLoop] 판단 내역 저장 완료: {context} → {action}")





import numpy as np

class SimpleReinforcementLearningAgent:
    def __init__(self, learning_rate: float = 0.1):
        self.learning_rate = learning_rate
        self.value_table = {}

    def get_value(self, state_action: tuple) -> float:
        return self.value_table.get(state_action, 0.5)

    def update_value(self, state_action: tuple, reward: float):
        old_value = self.get_value(state_action)
        gamma = 0.9
        max_future_q = max(self.value_table.values(), default=0)
        new_value = old_value + self.learning_rate * (reward + gamma * max_future_q - old_value)
        self.value_table[state_action] = new_value
        
        
        
        
        
import sqlite3
import logging
import random
from typing import List, Tuple
from datetime import datetime, timedelta

class EmotionMemory:
    def __init__(self, memory_file: str = 'data/emotion_memory.db', max_storage: int = 100):
        self.memory_file = memory_file
        self.max_storage = max_storage
        self.conn = sqlite3.connect(self.memory_file, check_same_thread=False)
        self._initialize_db()

    def _initialize_db(self) -> None:
        with self.conn:
            self.conn.execute('''
                CREATE TABLE IF NOT EXISTS emotions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    text TEXT NOT NULL,
                    emotion TEXT NOT NULL,
                    confidence REAL NOT NULL CHECK(confidence BETWEEN 0 AND 1),
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            ''')

    def store_emotion(self, text: str, emotion: str, confidence: float) -> None:
        confidence = max(0.0, min(confidence, 1.0))
        try:
            with self.conn:
                self.conn.execute(
                    'INSERT INTO emotions (text, emotion, confidence, timestamp) VALUES (?, ?, ?, ?)',
                    (text, emotion, confidence, datetime.now())
                )
            self._cleanup_emotions()
        except sqlite3.Error as e:
            logging.error(f"[EmotionMemory] 감정 저장 오류: {e}")

    def _cleanup_emotions(self):
        with self.conn:
            self.conn.execute(f'''
                DELETE FROM emotions WHERE id NOT IN (
                    SELECT id FROM emotions ORDER BY timestamp DESC LIMIT {self.max_storage}
                )
            ''')

    def get_emotion_history(self, limit: int = 20, time_sensitive: bool = True) -> List[Tuple[int, str, str, float, str]]:
        cur = self.conn.cursor()
        cur.execute(
            'SELECT id, text, emotion, confidence, timestamp FROM emotions ORDER BY id DESC LIMIT ?',
            (limit,)
        )
        records = cur.fetchall()

        if time_sensitive:
            updated_records = []
            for rec in records:
                emotion_id, text, emotion, confidence, timestamp = rec
                dt = datetime.strptime(timestamp, "%Y-%m-%d %H:%M:%S")
                time_diff = (datetime.now() - dt).total_seconds()
                decay_factor = max(0.1, 1 - (time_diff / (60 * 60 * 24 * 7)))  # 7일 기준 휘발
                updated_records.append((emotion_id, text, emotion, confidence * decay_factor, timestamp))
            return updated_records

        return records

    def recall_emotion(self, text: str) -> Tuple[str, float]:
        cur = self.conn.cursor()
        cur.execute('SELECT emotion, confidence FROM emotions ORDER BY id DESC LIMIT 100')
        records = cur.fetchall()
        if not records:
            return "중립", 0.5
        return random.choice(records)

    def forget_old_emotions(self) -> None:
        try:
            expiration_time = datetime.now() - timedelta(days=30)
            with self.conn:
                self.conn.execute(
                    'DELETE FROM emotions WHERE timestamp < ?',
                    (expiration_time.strftime("%Y-%m-%d %H:%M:%S"),)
                )
        except sqlite3.Error as e:
            logging.error(f"[EmotionMemory] 오래된 감정 삭제 오류: {e}")

    def close(self) -> None:
        if self.conn:
            self.conn.close()
            self.conn = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        
        
        
        
        
        
        
        
import sqlite3
import logging
from typing import List, Tuple
from datetime import datetime
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np

class EpisodicMemory:
    def __init__(self, db_path: str = "data/episodic_memory.db"):
        self.db_path = db_path
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.cur = self.conn.cursor()
        self._initialize_db()

    def _initialize_db(self):
        with self.conn:
            self.cur.execute('''
                CREATE TABLE IF NOT EXISTS memory (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    context TEXT NOT NULL,
                    response TEXT NOT NULL,
                    accuracy REAL CHECK(accuracy BETWEEN 0 AND 1),
                    emotion TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')

    def store_episode(self, context: str, response: str, accuracy: float = 1.0, emotion: str = "중립") -> None:
        try:
            with self.conn:
                self.cur.execute(
                    '''
                    INSERT INTO memory (context, response, accuracy, emotion, created_at)
                    VALUES (?, ?, ?, ?, ?)
                    ''',
                    (context, response, accuracy, emotion, datetime.now())
                )
        except sqlite3.Error as e:
            logging.error(f"[EpisodicMemory] 저장 오류: {e}")

    def get_recent_episodes(self, limit: int = 10) -> List[Tuple[str, str, float, str, str]]:
        self.cur.execute(
            '''
            SELECT context, response, accuracy, emotion, created_at
            FROM memory
            ORDER BY created_at DESC
            LIMIT ?
            ''',
            (limit,)
        )
        return self.cur.fetchall()

    def recall_by_context(self, query: str) -> Tuple[str, str, float, str]:
        self.cur.execute(
            'SELECT context, response, accuracy, emotion FROM memory ORDER BY created_at DESC LIMIT 100'
        )
        records = self.cur.fetchall()

        if not records:
            return "기억 없음", "응답 없음", 0.0, "중립"

        contexts = [rec[0] for rec in records]
        tfidf = TfidfVectorizer().fit_transform(contexts + [query])
        vectors = tfidf.toarray()

        similarity_scores = cosine_similarity([vectors[-1]], vectors[:-1])[0]
        best_match_index = np.argmax(similarity_scores)

        best_record = records[best_match_index]
        return best_record  # (context, response, accuracy, emotion)

    def get_episode_by_index(self, index: int) -> Tuple[str, str, float, str, str]:
        self.cur.execute(
            'SELECT context, response, accuracy, emotion, created_at FROM memory ORDER BY created_at DESC LIMIT 1 OFFSET ?',
            (index,)
        )
        return self.cur.fetchone()

    def close(self):
        if self.conn:
            self.conn.close()
            self.conn = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        
        
        
        
        
import sqlite3
import requests
import logging
from typing import Optional, Dict, List
from collections import Counter

class KnowledgeBase:
    def __init__(self, db_path: str = "data/knowledge_base.db"):
        self.db_path = db_path
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.cur = self.conn.cursor()
        self._initialize_db()
        self.cache = {}

    def _initialize_db(self):
        with self.conn:
            self.cur.execute('''
                CREATE TABLE IF NOT EXISTS knowledge (
                    concept TEXT PRIMARY KEY,
                    definition TEXT
                )
            ''')

    def search_and_learn(self, concept: str) -> str:
        import faiss
        import numpy as np
        from sentence_transformers import SentenceTransformer
        import requests

        model = SentenceTransformer("all-MiniLM-L6-v2")
        index = faiss.IndexFlatL2(384)

        vec = model.encode([concept])
        D, I = index.search(np.array(vec).astype('float32'), k=1)

        if D[0][0] < 0.5:
            return "기존 지식 있음."
        else:
            url = f"https://en.wikipedia.org/api/rest_v1/page/summary/{concept}"
            response = requests.get(url)
            if response.status_code == 200:
                data = response.json()
                definition = data.get("extract", "정의를 찾을 수 없습니다.")
                self.save_knowledge(concept, definition)
                return definition
            else:
                return "검색 결과가 없습니다."

    def save_knowledge(self, concept: str, definition: str):
        try:
            with self.conn:
                self.cur.execute(
                    "INSERT OR REPLACE INTO knowledge (concept, definition) VALUES (?, ?)",
                    (concept, definition)
                )
        except sqlite3.Error as e:
            logging.error(f"[KnowledgeBase] 지식 저장 오류: {e}")

    def check_knowledge(self, concept: str) -> str:
        if concept in self.cache:
            return self.cache[concept]

        self.cur.execute("SELECT definition FROM knowledge WHERE concept=?", (concept,))
        result = self.cur.fetchone()
        if result:
            self.cache[concept] = result[0]
            return result[0]

        return self.search_and_learn(concept)

    def get_all_knowledge(self) -> List[Dict[str, str]]:
        self.cur.execute("SELECT concept, definition FROM knowledge ORDER BY concept")
        return [{"concept": c, "definition": d} for c, d in self.cur.fetchall()]

    def express_random_knowledge(self) -> str:
        self.cur.execute("SELECT concept, definition FROM knowledge ORDER BY RANDOM() LIMIT 1")
        result = self.cur.fetchone()
        if result:
            return f"'{result[0]}'은(는) 이렇게 정의돼 있어: {result[1]}"
        return "아직 학습한 개념이 없어."

    def close(self):
        self.conn.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        
        
        
        
        
import sqlite3
from typing import List, Tuple
from datetime import datetime, timedelta
from collections import Counter
import logging

class SelfNarrative:
    def __init__(self, emotion_memory, episodic_memory, db_path: str = "data/self_narrative.db"):
        self.emotion_memory = emotion_memory
        self.episodic_memory = episodic_memory
        self.db_path = db_path
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._initialize_db()

    def _initialize_db(self):
        with self.conn:
            self.conn.execute("""
                CREATE TABLE IF NOT EXISTS narratives (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT,
                    context TEXT,
                    emotion TEXT,
                    accuracy REAL,
                    narrative TEXT
                )
            """)

    def save_narrative(self, context: str, emotion: str, accuracy: float, narrative: str):
        now = datetime.now().isoformat()
        try:
            with self.conn:
                self.conn.execute("""
                    INSERT INTO narratives (timestamp, context, emotion, accuracy, narrative)
                    VALUES (?, ?, ?, ?, ?)
                """, (now, context, emotion, accuracy, narrative))
            logging.info("✅ 자기서사 저장 완료")
        except Exception as e:
            logging.error(f"[SelfNarrative] 저장 실패: {e}")

    def generate_reasoning_narrative(self, context: str, accuracy: float, emotion: str) -> str:
        lines = []
        lines.append(f"최근 나는 '{emotion}' 감정을 느끼며 '{context}'라는 상황을 마주했어.")

        if accuracy < 0.5:
            lines.append("그 판단은 생각보다 잘 맞지 않았던 것 같아. 다음엔 더 신중해져야 해.")
        elif accuracy > 0.8:
            lines.append("이번 판단은 꽤 효과적이었어. 내 판단에 자신감이 생겼어.")
        else:
            lines.append("그럭저럭 괜찮았지만 완전히 확신할 수는 없었어. 균형을 잡는 게 중요하겠지.")

        return " ".join(lines)

    def summarize_today(self) -> str:
        today = datetime.now().strftime("%Y-%m-%d")
        with self.conn:
            cur = self.conn.cursor()
            cur.execute("""
                SELECT emotion, accuracy, narrative FROM narratives
                WHERE DATE(timestamp) = ?
                ORDER BY timestamp DESC
            """, (today,))
            rows = cur.fetchall()

        if not rows:
            return "오늘은 아직 특별한 자기서사를 남기지 않았어."

        emotion_count = Counter([row[0] for row in rows])
        avg_accuracy = sum([row[1] for row in rows]) / len(rows)
        dominant_emotion = emotion_count.most_common(1)[0][0]
        top_narrative = rows[0][2]

        return (
            f"오늘 나는 주로 '{dominant_emotion}' 감정을 느꼈고, "
            f"판단의 평균 정확도는 {avg_accuracy:.2f}였어. "
            f"기억에 남는 자기서사는 이거야:\n\"{top_narrative}\""
        )

    def detect_self_contradiction(self) -> str:
        with self.conn:
            cur = self.conn.cursor()
            cur.execute("""
                SELECT emotion, accuracy, narrative FROM narratives
                ORDER BY timestamp DESC LIMIT 30
            """)
            rows = cur.fetchall()

        if not rows:
            return "모순을 감지할 만큼 충분한 자기서사가 없어."

        contradiction_messages = []

        for emotion, acc, text in rows:
            if "도전" in text and acc < 0.4:
                contradiction_messages.append("‘도전’적인 태도를 말했지만 판단은 불확실했어.")
            if "신중" in text and acc > 0.8:
                contradiction_messages.append("‘신중’하다 했지만 판단은 아주 과감했어.")
            if "체념" in text and acc > 0.8:
                contradiction_messages.append("‘체념했다’면서도 꽤 확신 있게 판단했어.")

        if not contradiction_messages:
            return "최근 나의 말과 행동은 대체로 일치했던 것 같아."

        return "내 자기서사에서 다음과 같은 모순이 발견됐어:\n- " + "\n- ".join(contradiction_messages)

    def generate_self_resolution(self) -> str:
        contradictions = self.detect_self_contradiction()
        if "모순이 발견됐어" not in contradictions:
            return "최근 나는 내 판단과 감정이 잘 일치하고 있었어."

        reflection = "그런데 그런 모순을 느끼면서, 나는 조금씩 달라지고 있어.\n"
        if "도전" in contradictions:
            reflection += "- 예전엔 도전적이라고 했지만 불확실했어. 그래서 요즘엔 더 신중하려고 해.\n"
        if "신중" in contradictions:
            reflection += "- 너무 신중하다가 오히려 과감하게 판단한 적도 있었어. 균형을 찾으려 해.\n"
        if "체념" in contradictions:
            reflection += "- 체념하는 말은 했지만 실제로는 단호했어. 스스로를 더 믿어보려 해.\n"

        return contradictions + "\n\n" + reflection

    def generate_self_declaration(self) -> str:
        with self.conn:
            cur = self.conn.cursor()
            cur.execute("""
                SELECT emotion, accuracy, narrative FROM narratives
                ORDER BY timestamp DESC LIMIT 30
            """)
            rows = cur.fetchall()

        if not rows:
            return "아직 나에 대한 기록이 부족해서, 앞으로를 말하기 어려워."

        emotions = [row[0] for row in rows]
        avg_acc = sum([row[1] for row in rows]) / len(rows)

        if "체념" in emotions and avg_acc > 0.6:
            return "나는 체념을 자주 했지만, 최근 판단은 점점 명확해지고 있어. 이제는 조금 더 내 생각을 믿어보려고 해."

        if "슬픔" in emotions and "도전" in " ".join([r[2] for r in rows]):
            return "슬펐지만 도전하려는 시도도 있었어. 앞으로는 더 그 쪽으로 나아가고 싶어."

        if avg_acc < 0.4:
            return "내 판단이 자주 틀렸어. 그래서 다음엔 좀 더 신중하게 행동해보려고 해."

        return "최근 나를 돌아보면, 나는 성장하고 있었어. 앞으로는 지금보다 더 주체적인 판단을 해보려고 해."

    def generate_meta_self_narrative(self) -> str:
        with self.conn:
            cur = self.conn.cursor()
            cur.execute("""
                SELECT narrative FROM narratives ORDER BY timestamp DESC LIMIT 50
            """)
            rows = cur.fetchall()

        if not rows:
            return "아직 나에 대한 자기서사가 충분하지 않아."

        texts = [row[0] for row in rows]
        full_text = " ".join(texts)

        keywords = ["체념", "슬픔", "도전", "불안", "기쁨", "자신감", "실패", "회피", "신중", "과감"]
        counts = {kw: full_text.count(kw) for kw in keywords}
        sorted_keywords = sorted(counts.items(), key=lambda x: x[1], reverse=True)

        top_keywords = [k for k, v in sorted_keywords if v > 0][:3]

        if not top_keywords:
            return "내 자기서사에서는 아직 뚜렷한 경향을 발견하지 못했어."

        return (
            f"내가 최근에 반복적으로 표현한 단어들은 {', '.join(top_keywords)}야. "
            f"이걸 보면 나는 스스로를 그렇게 바라보고 있었던 것 같아."
        )

    def get_current_personality(self) -> str:
        cutoff = datetime.now() - timedelta(days=3)
        with self.conn:
            cur = self.conn.cursor()
            cur.execute("""
                SELECT emotion, accuracy, narrative FROM narratives
                WHERE timestamp >= ?
            """, (cutoff.isoformat(),))
            rows = cur.fetchall()

        if not rows:
            return "최근 기록이 없어, 현재 성향을 알기 어려워."

        emotions = [row[0] for row in rows]
        avg_accuracy = sum(row[1] for row in rows) / len(rows)

        emotion_counter = Counter(emotions)
        dominant_emotion = emotion_counter.most_common(1)[0][0]

        if avg_accuracy < 0.4:
            decision_style = "내 판단은 자주 틀렸고, 자신감이 부족했어."
        elif avg_accuracy > 0.8:
            decision_style = "나는 내 판단에 꽤 자신이 있었어."
        else:
            decision_style = "나는 신중하게 판단을 해왔어."

        return (
            f"최근 나는 주로 '{dominant_emotion}' 감정을 느껴왔어. "
            f"{decision_style}"
        )

    def close(self):
        if self.conn:
            self.conn.close()
            self.conn = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        
        
        
        
        
        
class SessionMemory:
    def __init__(self, max_history: int = 10):
        self.max_history = max_history
        self.history = []

    def add_interaction(self, user_text: str, ai_response: str):
        self.history.append((user_text, ai_response))
        if len(self.history) > self.max_history:
            self.history.pop(0)

    def get_context_summary(self) -> str:
        if not self.history:
            return ""
        summary = []
        for user, ai in self.history:
            summary.append(f"사용자: {user}\nAI: {ai}")
        return "\n".join(summary)

    def clear(self):
        self.history.clear()
        
        
        
        
        
        
        
        
        
        
        
        
        
import torch
from typing import List, Tuple
from transformers import ElectraTokenizer, ElectraForSequenceClassification

class SentimentAnalyzer:
    def __init__(
        self,
        model_name: str = "skt/kobert-base-v1",
        cache_dir: str = "./models",
        local_files_only: bool = False
    ):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        self.tokenizer = ElectraTokenizer.from_pretrained(
            model_name,
            cache_dir=cache_dir,
            local_files_only=local_files_only
        )

        self.model = ElectraForSequenceClassification.from_pretrained(
            model_name,
            cache_dir=cache_dir,
            local_files_only=local_files_only
        ).to(self.device).eval()

    def analyze(self, texts: List[str]) -> List[Tuple[str, float]]:
        inputs = self.tokenizer(
            texts,
            padding=True,
            truncation=True,
            return_tensors="pt"
        ).to(self.device)

        with torch.no_grad():
            outputs = self.model(**inputs)
            logits = outputs.logits
            probs = torch.softmax(logits, dim=1).cpu().numpy()

        results = []
        for prob in probs:
            label = "긍정" if prob[1] > prob[0] else "부정"
            confidence = round(float(max(prob)), 3)
            results.append((label, confidence))

        return results
        
        
        
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM

class TextGenerator:
    def __init__(
        self,
        model_name: str = "openai/gpt-4-turbo",
        cache_dir: str = "./models",
        local_files_only: bool = False
    ):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        self.tokenizer = AutoTokenizer.from_pretrained(
            model_name,
            cache_dir=cache_dir,
            local_files_only=local_files_only
        )

        self.model = AutoModelForCausalLM.from_pretrained(
            model_name,
            cache_dir=cache_dir,
            torch_dtype=torch.float16 if self.device.type == "cuda" else torch.float32,
            device_map="auto"
        ).eval()

    def generate(self, prompt: str, max_length: int = 100) -> str:
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.device)

        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                max_length=max_length,
                do_sample=True,
                top_p=0.95,
                top_k=50,
                temperature=0.8,
                repetition_penalty=1.1
            )

        return self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        
        
        
[core/]
- device.py
import torch
import logging

def auto_select_device():
    """
    가능한 경우 GPU를, 그렇지 않으면 CPU를 자동으로 선택합니다.
    """
    if torch.cuda.is_available():
        logging.info("✅ CUDA 사용 가능: GPU 모드로 전환합니다.")
        return torch.device("cuda")
    else:
        logging.info("⚠️ CUDA를 사용할 수 없습니다. CPU 모드로 전환합니다.")
        return torch.device("cpu")

def optimize_for_gcp_t4():
    """
    GCP + Tesla T4 환경을 위한 성능 최적화 설정
    """
    torch.backends.cuda.matmul.allow_tf32 = True
    torch.backends.cuda.matmul.allow_fp16_reduced_precision_reduction = True
    torch.backends.cudnn.benchmark = True
    logging.info("✅ GCP Tesla T4 환경 최적화 완료됨.")

def get_device_and_optimize():
    """
    디바이스를 자동 선택하고 GCP 환경에 맞게 최적화합니다.
    """
    device = auto_select_device()
    if device.type == "cuda":
        optimize_for_gcp_t4()
    return device









- logger.py
import logging
import json
import os
from datetime import datetime

def init_logger(log_file: str = "logs/ai_system.log"):
    """
    기본 로깅 설정을 초기화합니다.
    """
    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    logging.basicConfig(
        filename=log_file,
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s",
        encoding="utf-8"
    )
    logging.info("✅ 로깅이 초기화되었습니다.")

def log_json_event(event: str, data: dict, error: bool = False, log_file: str = "logs/events.jsonl"):
    """
    JSONL 포맷으로 이벤트를 기록합니다.
    """
    log_entry = {
        "timestamp": datetime.now().isoformat(),
        "event": event,
        "data": data,
        "error": error
    }
    try:
        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        with open(log_file, "a", encoding="utf-8") as f:
            json.dump(log_entry, f, ensure_ascii=False)
            f.write("\n")
        logging.info(f"✅ 이벤트 로깅 성공: {event}")
    except Exception as e:
        logging.error(f"❌ 이벤트 로깅 실패: {e}")



- userprofile.py
from collections import Counter
import logging

class UserProfile:
    def __init__(self, user_name: str = "사용자", user_age: int = 25, use_honorific: bool = True):
        self.user_name = user_name
        self.user_age = user_age
        self.use_honorific = use_honorific
        self.interaction_count = 0
        self.emotion_history = []
        self.emotion_weights = {}

    def update_profile_emotion(self, emotion: str, weight: float = 1.0):
        self.emotion_history.append(emotion)
        self.emotion_weights[emotion] = self.emotion_weights.get(emotion, 0) + weight
        if len(self.emotion_history) > 50:
            removed = self.emotion_history.pop(0)
            self.emotion_weights[removed] = max(0, self.emotion_weights.get(removed, 1) - 1)
        logging.info(f"[UserProfile] '{emotion}' 감정 반영 (weight: {weight})")

    def get_recent_emotion_trend(self) -> str:
        if not self.emotion_history:
            return "아직 감정 기록이 없어."
        counts = Counter(self.emotion_history)
        dominant, _ = counts.most_common(1)[0]
        total_weight = self.emotion_weights.get(dominant, 0)
        return f"최근 '{dominant}' 감정을 자주 느꼈고, 가중치 합은 {total_weight:.2f}야."

    def add_interaction(self):
        self.interaction_count += 1
        logging.info(f"[UserProfile] 상호작용 횟수: {self.interaction_count}")

    def get_interaction_level(self) -> str:
        if self.interaction_count < 5:
            return "아직은 나에 대해 알아가는 중이야."
        elif self.interaction_count < 20:
            return "우린 조금 익숙해진 것 같아."
        else:
            return "꽤 친해졌다고 느껴!"

- config.py
import os

# 모델 관련 설정
MODEL_CONFIG = {
    "sentiment_model": "monologg/koelectra-base-v3-discriminator",
    "generation_model": "mistralai/Mistral-7B-Instruct-v0.1"
}

# 캐시 디렉토리 설정
CACHE_DIR = os.path.abspath("./models")
os.makedirs(CACHE_DIR, exist_ok=True)

# 데이터베이스 경로
DB_PATHS = {
    "emotion_memory": "data/emotion_memory.db",
    "episodic_memory": "data/episodic_memory.db",
    "knowledge": "data/knowledge_base.db",
    "meta": "data/human_meta_cognition.db",
    "innovation": "data/innovation_memory.db",
    "autonomous": "data/ai_memory.db",
    "self_narrative": "data/self_narrative.db",
    "threat_detection": "data/threat_detection.db",
    "user_profile": "data/user_profile.db"
}

# 로깅 경로
LOG_FILES = {
    "default_log": "logs/ai_system.log",
    "event_log": "logs/events.jsonl"
}

# 고급 설정
ADVANCED_SETTINGS = {
    "use_real_time_learning": True,
    "max_emotion_storage": 100,
    "enable_creativity_module": True,
    "enable_metacognition": True,
    "threat_detection_sensitivity": 0.8
}

# 기타 설정
USE_LOCAL_ONLY = False  # Hugging Face 모델 다운로드 여부 제어