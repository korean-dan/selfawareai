import torch
from typing import List, Tuple
from transformers import ElectraTokenizer, ElectraForSequenceClassification

class SentimentAnalyzer:
    def __init__(
        self,
        model_name: str = "skt/kobert-base-v1",
        cache_dir: str = "./models",
        local_files_only: bool = False
    ):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        self.tokenizer = ElectraTokenizer.from_pretrained(
            model_name,
            cache_dir=cache_dir,
            local_files_only=local_files_only
        )

        self.model = ElectraForSequenceClassification.from_pretrained(
            model_name,
            cache_dir=cache_dir,
            local_files_only=local_files_only
        ).to(self.device).eval()

    def analyze(self, texts: List[str]) -> List[Tuple[str, float]]:
        inputs = self.tokenizer(
            texts,
            padding=True,
            truncation=True,
            return_tensors="pt"
        ).to(self.device)

        with torch.no_grad():
            outputs = self.model(**inputs)
            logits = outputs.logits
            probs = torch.softmax(logits, dim=1).cpu().numpy()

        results = []
        for prob in probs:
            label = "긍정" if prob[1] > prob[0] else "부정"
            confidence = round(float(max(prob)), 3)
            results.append((label, confidence))

        return results