import logging
import json
import os
from datetime import datetime

def init_logger(log_file: str = "logs/ai_system.log"):
    """
    기본 로깅 설정을 초기화합니다.
    """
    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    logging.basicConfig(
        filename=log_file,
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s",
        encoding="utf-8"
    )
    logging.info("✅ 로깅이 초기화되었습니다.")

def log_json_event(event: str, data: dict, error: bool = False, log_file: str = "logs/events.jsonl"):
    """
    JSONL 포맷으로 이벤트를 기록합니다.
    """
    log_entry = {
        "timestamp": datetime.now().isoformat(),
        "event": event,
        "data": data,
        "error": error
    }
    try:
        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        with open(log_file, "a", encoding="utf-8") as f:
            json.dump(log_entry, f, ensure_ascii=False)
            f.write("\n")
        logging.info(f"✅ 이벤트 로깅 성공: {event}")
    except Exception as e:
        logging.error(f"❌ 이벤트 로깅 실패: {e}")