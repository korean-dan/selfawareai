from collections import Counter
import logging

class UserProfile:
    def __init__(self, user_name: str = "사용자", user_age: int = 25, use_honorific: bool = True):
        self.user_name = user_name
        self.user_age = user_age
        self.use_honorific = use_honorific
        self.interaction_count = 0
        self.emotion_history = []
        self.emotion_weights = {}

    def update_profile_emotion(self, emotion: str, weight: float = 1.0):
        self.emotion_history.append(emotion)
        self.emotion_weights[emotion] = self.emotion_weights.get(emotion, 0) + weight
        if len(self.emotion_history) > 50:
            removed = self.emotion_history.pop(0)
            self.emotion_weights[removed] = max(0, self.emotion_weights.get(removed, 1) - 1)
        logging.info(f"[UserProfile] '{emotion}' 감정 반영 (weight: {weight})")

    def get_recent_emotion_trend(self) -> str:
        if not self.emotion_history:
            return "아직 감정 기록이 없어."
        counts = Counter(self.emotion_history)
        dominant, _ = counts.most_common(1)[0]
        total_weight = self.emotion_weights.get(dominant, 0)
        return f"최근 '{dominant}' 감정을 자주 느꼈고, 가중치 합은 {total_weight:.2f}야."

    def add_interaction(self):
        self.interaction_count += 1
        logging.info(f"[UserProfile] 상호작용 횟수: {self.interaction_count}")

    def get_interaction_level(self) -> str:
        if self.interaction_count < 5:
            return "아직은 나에 대해 알아가는 중이야."
        elif self.interaction_count < 20:
            return "우린 조금 익숙해진 것 같아."
        else:
            return "꽤 친해졌다고 느껴!"