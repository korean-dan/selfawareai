import torch
import logging

def auto_select_device():
    """
    가능한 경우 GPU를, 그렇지 않으면 CPU를 자동으로 선택합니다.
    """
    if torch.cuda.is_available():
        logging.info("✅ CUDA 사용 가능: GPU 모드로 전환합니다.")
        return torch.device("cuda")
    else:
        logging.info("⚠️ CUDA를 사용할 수 없습니다. CPU 모드로 전환합니다.")
        return torch.device("cpu")

def optimize_for_gcp_t4():
    """
    GCP + Tesla T4 환경을 위한 성능 최적화 설정
    """
    torch.backends.cuda.matmul.allow_tf32 = True
    torch.backends.cuda.matmul.allow_fp16_reduced_precision_reduction = True
    torch.backends.cudnn.benchmark = True
    logging.info("✅ GCP Tesla T4 환경 최적화 완료됨.")

def get_device_and_optimize():
    """
    디바이스를 자동 선택하고 GCP 환경에 맞게 최적화합니다.
    """
    device = auto_select_device()
    if device.type == "cuda":
        optimize_for_gcp_t4()
    return device