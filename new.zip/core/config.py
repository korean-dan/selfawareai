import os

# 모델 관련 설정
MODEL_CONFIG = {
    "sentiment_model": "monologg/koelectra-base-v3-discriminator",
    "generation_model": "mistralai/Mistral-7B-Instruct-v0.1"
}

# 캐시 디렉토리 설정
CACHE_DIR = os.path.abspath("./models")
os.makedirs(CACHE_DIR, exist_ok=True)

# 데이터베이스 경로
DB_PATHS = {
    "emotion_memory": "data/emotion_memory.db",
    "episodic_memory": "data/episodic_memory.db",
    "knowledge": "data/knowledge_base.db",
    "meta": "data/human_meta_cognition.db",
    "innovation": "data/innovation_memory.db",
    "autonomous": "data/ai_memory.db",
    "self_narrative": "data/self_narrative.db",
    "threat_detection": "data/threat_detection.db",
    "user_profile": "data/user_profile.db"
}

# 로깅 경로
LOG_FILES = {
    "default_log": "logs/ai_system.log",
    "event_log": "logs/events.jsonl"
}

# 고급 설정
ADVANCED_SETTINGS = {
    "use_real_time_learning": True,
    "max_emotion_storage": 100,
    "enable_creativity_module": True,
    "enable_metacognition": True,
    "threat_detection_sensitivity": 0.8
}

# 기타 설정
USE_LOCAL_ONLY = False  # Hugging Face 모델 다운로드 여부 제어