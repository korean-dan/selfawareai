import numpy as np

class SimpleReinforcementLearningAgent:
    def __init__(self, learning_rate: float = 0.1):
        self.learning_rate = learning_rate
        self.value_table = {}

    def get_value(self, state_action: tuple) -> float:
        return self.value_table.get(state_action, 0.5)

    def update_value(self, state_action: tuple, reward: float):
        old_value = self.get_value(state_action)
        gamma = 0.9
        max_future_q = max(self.value_table.values(), default=0)
        new_value = old_value + self.learning_rate * (reward + gamma * max_future_q - old_value)
        self.value_table[state_action] = new_value