from cognition.emotion_core import EmotionCore
from cognition.threat_detection import ThreatDetector
from cognition.needs_system import NeedsSystem
from cognition.creativity import CreativeEngine
from cognition.decision_engine import DecisionEngine
from memory.self_narrative import SelfNarrative
from typing import Dict
import logging

class CognitiveLoop:
    def __init__(self, modules: Dict[str, object]):
        self.emotion = modules["emotion"]
        self.threat = modules["threat"]
        self.needs = modules["needs"]
        self.creativity = modules["creativity"]
        self.decision = modules["decision"]
        self.self_narrative = modules["self_narrative"]

    def run(self, input_text: str) -> Dict[str, str]:
        threat_level = self._evaluate_threat(input_text)
        needs_state = self._analyze_needs()
        self._update_emotion(threat_level, needs_state)

        monologue = self._generate_inner_monologue()
        creative_outputs = self._generate_creative_options(monologue)
        chosen_action = self._choose_action(creative_outputs, monologue)

        self._log_decision(input_text, chosen_action)

        return {
            "inner_monologue": monologue,
            "emotion": self.emotion.get_dominant_emotion(),
            "action": chosen_action
        }

    def _evaluate_threat(self, text: str) -> str:
        label, score = self.threat.analyze_threat(text)
        logging.info(f"[CognitiveLoop] 위협 분석 결과: {label} ({score})")
        return label

    def _analyze_needs(self) -> Dict[str, float]:
        state = self.needs.get_needs_state()
        logging.info(f"[CognitiveLoop] 욕구 상태: {state}")
        return state

    def _update_emotion(self, threat_label: str, needs_state: Dict[str, float]):
        if threat_label == "위험":
            self.emotion.update_emotion("두려움", 0.4)
        else:
            self.emotion.update_emotion("호기심", 0.2)

        if needs_state.get("안정감", 0) < 0.3:
            self.emotion.update_emotion("불안함", 0.3)

    def _generate_inner_monologue(self) -> str:
        monologue = self.self_narrative.generate_meta_self_narrative()
        logging.info(f"[CognitiveLoop] 생성된 내면 독백:\n{monologue}")
        return monologue

    def _generate_creative_options(self, context: str) -> list:
        idea, originality = self.creativity.generate_solution(context, self.emotion.get_dominant_emotion())
        logging.info(f"[CognitiveLoop] 생성된 창의 대안: {idea} (originality: {originality:.2f})")
        return [idea]

    def _choose_action(self, options: list, context: str) -> str:
        decision = self.decision.make_decision(context, options)
        logging.info(f"[CognitiveLoop] 최종 선택된 행동: {decision}")
        return decision

    def _log_decision(self, context: str, action: str):
        emotion = self.emotion.get_dominant_emotion()
        narrative = self.self_narrative.generate_reasoning_narrative(context, 0.8, emotion)
        self.self_narrative.save_narrative(context, emotion, 0.8, narrative)
        logging.info(f"[CognitiveLoop] 판단 내역 저장 완료: {context} → {action}")