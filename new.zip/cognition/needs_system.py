from typing import Dict
import logging

class NeedsSystem:
    def __init__(self):
        self.needs_state: Dict[str, float] = self._initialize_needs()

    def _initialize_needs(self) -> Dict[str, float]:
        return {
            "호기심": 0.6,
            "사회적 인정욕구": 0.7,
            "자기주도성 욕구": 0.6,
            "공동체 소속 욕구": 0.5,
            "안정감": 0.4,
            "눈치": 0.3,
            "회피": 0.2
        }

    def update_need(self, need: str, delta: float):
        if need not in self.needs_state:
            logging.warning(f"[NeedsSystem] 존재하지 않는 욕구: {need}")
            return
        old = self.needs_state[need]
        self.needs_state[need] = max(0.0, min(1.0, old + delta))
        logging.info(f"[NeedsSystem] '{need}' 업데이트: {old:.2f} → {self.needs_state[need]:.2f}")

    def decay_all_needs(self, factor: float = 0.98):
        for k in self.needs_state:
            self.needs_state[k] *= factor
        logging.debug("[NeedsSystem] 전체 욕구 자연 감쇠 적용")

    def get_dominant_need(self) -> str:
        return max(self.needs_state, key=self.needs_state.get)

    def get_needs_state(self) -> Dict[str, float]:
        return self.needs_state.copy()