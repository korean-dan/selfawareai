from openai import OpenAI
import sqlite3
import logging
from typing import Tuple

class ThreatDetector:
    def __init__(self, db_path: str = "data/threat_detection.db"):
        # OpenAI API 클라이언트 초기화 (GPT 기반 위협탐지)
        self.client = OpenAI(api_key='your_openai_api_key')  # 반드시 여기에 실제 API 키 입력!

        # 데이터베이스 설정 (기존 유지)
        self.db_path = db_path
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._initialize_db()

    def _initialize_db(self):
        with self.conn:
            self.conn.execute('''
                CREATE TABLE IF NOT EXISTS threats (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    text TEXT NOT NULL,
                    label TEXT NOT NULL,
                    score REAL NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
        logging.info("[ThreatDetector] 위협 DB 초기화 완료")

    def analyze_threat(self, text: str) -> Tuple[str, float]:
        # GPT 기반 Few-shot으로 위협 탐지 수행
        response = self.client.chat.completions.create(
            model="gpt-4-turbo",
            messages=[
                {"role": "system", "content": "입력된 메시지를 분석하여 'dangerous' 또는 'safe'로만 응답하라."},
                {"role": "user", "content": text}
            ],
            max_tokens=1,
            temperature=0
        )
        
        label = response.choices[0].message.content.strip().lower()
        if label not in ["dangerous", "safe"]:
            label = "safe"  # 예외 처리 (예상 외 답변 방지)

        threat_score = 0.9 if label == "dangerous" else 0.1

        self._save_to_db(text, label, threat_score)
        logging.info(f"[ThreatDetector] '{text}' 분석 결과: {label} ({threat_score})")
        return label, threat_score

    def _save_to_db(self, text: str, label: str, score: float):
        try:
            with self.conn:
                self.conn.execute(
                    'INSERT INTO threats (text, label, score) VALUES (?, ?, ?)',
                    (text, label, score)
                )
        except sqlite3.Error as e:
            logging.error(f"[ThreatDetector] DB 저장 오류: {e}")

    def close(self):
        if self.conn:
            self.conn.close()
            self.conn = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()