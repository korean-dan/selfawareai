from cognition.emotion_core import EmotionCore
from cognition.needs_system import NeedsSystem
from cognition.metacognition import MetaCognition
from collections import Counter

class StateSummary:
    def __init__(self, emotion_engine: EmotionCore, needs_engine: NeedsSystem, bias_engine: MetaCognition):
        self.emotion_engine = emotion_engine
        self.needs_engine = needs_engine
        self.bias_engine = bias_engine

    def summarize_emotion(self) -> str:
        state = self.emotion_engine.get_emotion_state()
        top = max(state.items(), key=lambda x: x[1])
        return f"현재 감정 상태에서 가장 강한 감정은 '{top[0]}' ({top[1]:.2f})입니다."

    def summarize_needs(self) -> str:
        state = self.needs_engine.get_needs_state()
        top = max(state.items(), key=lambda x: x[1])
        return f"가장 두드러진 현재 욕구는 '{top[0]}' ({top[1]:.2f})입니다."

    def summarize_biases(self, limit: int = 3) -> str:
        trends = self.bias_engine.get_bias_trends()
        if not trends:
            return "현재 기록된 편향 정보가 없습니다."
        summary = [f"{k}: {v:.2f}" for k, v in list(trends.items())[:limit]]
        return "최근 사고 편향:\n" + "\n".join(summary)

    def full_summary(self) -> str:
        return "\n".join([
            self.summarize_emotion(),
            self.summarize_needs(),
            self.summarize_biases()
        ])

    def get_state_snapshot(self) -> dict:
        return {
            "emotion": self.emotion_engine.get_emotion_state(),
            "needs": self.needs_engine.get_needs_state(),
            "bias": self.bias_engine.get_bias_trends()
        }

    def dominant_emotion_label(self) -> str:
        state = self.emotion_engine.get_emotion_state()
        return max(state.items(), key=lambda x: x[1])[0]

    def dominant_need_label(self) -> str:
        state = self.needs_engine.get_needs_state()
        return max(state.items(), key=lambda x: x[1])[0]

    def summarize_emotion_distribution(self) -> str:
        state = self.emotion_engine.get_emotion_state()
        sorted_emotions = sorted(state.items(), key=lambda x: x[1], reverse=True)
        return "감정 분포:\n" + "\n".join([f"{k}: {v:.2f}" for k, v in sorted_emotions])

    def summarize_need_distribution(self) -> str:
        state = self.needs_engine.get_needs_state()
        sorted_needs = sorted(state.items(), key=lambda x: x[1], reverse=True)
        return "욕구 분포:\n" + "\n".join([f"{k}: {v:.2f}" for k, v in sorted_needs])

    def summarize_state_by_threshold(self, threshold: float = 0.7) -> str:
        emotions = self.emotion_engine.get_emotion_state()
        needs = self.needs_engine.get_needs_state()
        strong_emotions = [f"{k}({v:.2f})" for k, v in emotions.items() if v >= threshold]
        strong_needs = [f"{k}({v:.2f})" for k, v in needs.items() if v >= threshold]
        return f"강한 감정: {', '.join(strong_emotions) if strong_emotions else '없음'}\n강한 욕구: {', '.join(strong_needs) if strong_needs else '없음'}"

    def top_n_emotions(self, n: int = 3) -> list:
        state = self.emotion_engine.get_emotion_state()
        return sorted(state.items(), key=lambda x: x[1], reverse=True)[:n]

    def top_n_needs(self, n: int = 3) -> list:
        state = self.needs_engine.get_needs_state()
        return sorted(state.items(), key=lambda x: x[1], reverse=True)[:n]