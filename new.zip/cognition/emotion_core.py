import numpy as np
import logging
from typing import Dict

class EmotionCore:
    def __init__(self):
        self.emotion_state: Dict[str, float] = self._initialize_emotions()

    def _initialize_emotions(self) -> Dict[str, float]:
        return {
            "기쁨": 0.5,
            "슬픔": 0.5,
            "두려움": 0.5,
            "분노": 0.5,
            "정": 0.3,
            "한": 0.0,
            "눈치": 0.5,
            "답답함": 0.2,
            "우울함": 0.0,
            "불안함": 0.0,
            "체념": 0.0,
            "무감각": 0.0
        }

        def update_emotion(self, emotion: str, intensity: float = 0.5):
        prob = np.random.beta(2, 5) * intensity
        for emo in self.emotion_state:
            self.emotion_state[emo] *= (1 - prob)
        if emotion in self.emotion_state:
            self.emotion_state[emotion] += prob

        # 감정 전이 로직
        if self.emotion_state["슬픔"] > 0.7:
            self.emotion_state["우울함"] = min(1.0, self.emotion_state["우울함"] + 0.2)
        if self.emotion_state["분노"] > 0.8:
            self.emotion_state["체념"] = min(1.0, self.emotion_state["체념"] + 0.3)
        if self.emotion_state["두려움"] > 0.6:
            self.emotion_state["불안함"] = min(1.0, self.emotion_state["불안함"] + 0.2)
        if self.emotion_state[emotion] > 0.9:
            self.emotion_state["무감각"] = min(1.0, self.emotion_state["무감각"] + 0.5)
            logging.info(f"[EmotionCore] '{emotion}' 감정 피로 → 무감각 전이")

    def get_dominant_emotion(self) -> str:
        return max(self.emotion_state, key=self.emotion_state.get)

    def get_emotion_state(self) -> Dict[str, float]:
        return self.emotion_state.copy()