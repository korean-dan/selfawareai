# cognition/decision_engine.py 최종 완성본 (모든 기능 유지)
from typing import List, Tuple, Optional
from cognition.emotion_core import EmotionCore
from cognition.needs_system import NeedsSystem
from cognition.metacognition import MetaCognition
from cognition.advanced_rl_agent import AdvancedRLAgent  # ★교체됨
from memory.episodic_memory import EpisodicMemory
from sklearn.metrics.pairwise import cosine_similarity
from sentence_transformers import SentenceTransformer
import numpy as np
import random
import logging
import torch

class DecisionEngine:
    def __init__(
        self,
        emotion_engine: EmotionCore,
        needs_engine: NeedsSystem,
        bias_engine: Optional[MetaCognition] = None,
        memory_engine: Optional[EpisodicMemory] = None
    ):
        self.emotion_engine = emotion_engine
        self.needs_engine = needs_engine
        self.bias_engine = bias_engine
        self.memory_engine = memory_engine

        self.embedding_model = SentenceTransformer('all-MiniLM-L6-v2')
        self.cached_embeddings = None
        self.cached_contexts = []

        # ★ 반드시 AdvancedRLAgent로 변경하여 초기화
        self.rl_agent = AdvancedRLAgent(state_size=384, action_size=10)

        self.personality = None

    def update_embedding_cache(self):
        episodes = self.memory_engine.get_recent_episodes(limit=50)
        self.cached_contexts = [ep[0] for ep in episodes]
        if self.cached_contexts:
            self.cached_embeddings = self.embedding_model.encode(self.cached_contexts)
        else:
            self.cached_embeddings = None

    def recall_memory(self, context: str) -> Tuple[str, float]:
        if not self.memory_engine:
            return "기억 없음", 0.0
        if self.cached_embeddings is None or len(self.cached_contexts) == 0:
            self.update_embedding_cache()
        if self.cached_embeddings is None:
            return "기억 없음", 0.0

        context_embedding = self.embedding_model.encode([context])[0]
        similarity_scores = cosine_similarity([context_embedding], self.cached_embeddings)[0]
        best_index = int(np.argmax(similarity_scores))
        best_episode = self.memory_engine.get_episode_by_index(best_index)
        logging.info(f"[DecisionEngine] 회상된 기억: {best_episode[0][:30]}... → {best_episode[1][:30]}...")
        return best_episode[1], best_episode[2]

    def fallback_to_default_response(self, context: str) -> str:
        return f"'{context}'에 대해선 아직 충분한 판단 데이터가 없어. 좀 더 생각해볼게."

    def generate_new_thought(self, context: str) -> str:
        options = [
            "전혀 다른 관점에서 접근해보자.",
            "직관에 의존해서 판단해볼까?",
            "기억이 없다면 창의적으로 풀어보자.",
            "감정적으로는 이 방향이 더 끌려.",
            "지금은 새로운 해석이 필요해."
        ]
        return random.choice(options)

    def predict_response(self, context: str) -> Tuple[str, float, str]:
        recalled_response, accuracy = self.recall_memory(context)
        if recalled_response == "기억 없음":
            fallback = self.fallback_to_default_response(context)
            return fallback, 0.2, "기억 없음"

        bias = self.bias_engine.get_bias(context) if self.bias_engine else 0.0
        adjusted_accuracy = max(0.0, min(1.0, accuracy + bias))

        if adjusted_accuracy < 0.5:
            creative = self.generate_new_thought(context)
            return creative, 0.5, "전략 전환"
        elif adjusted_accuracy < 0.75:
            return recalled_response, adjusted_accuracy, "전략 유지"
        else:
            return recalled_response, adjusted_accuracy, "전략 확신"

    def make_decision(self, context: str, options: List[str]) -> str:
        context_embedding = self.embedding_model.encode([context])[0]
        
        # 강화학습 에이전트를 통한 행동 선택
        action_idx, log_prob = self.rl_agent.select_action(context_embedding)
        chosen_option = options[action_idx % len(options)]

        logging.info(f"[DecisionEngine] 최종 선택: '{chosen_option}' (action_idx: {action_idx})")
        return chosen_option

    def decision_reasoning_narrative(self, context: str, chosen: str, accuracy: float, strategy: str) -> str:
        lines = [f"'{context}'에 대해 나는 '{chosen}'을 선택했어."]
        if strategy == "전략 전환":
            lines.append("이전 판단은 신뢰도가 낮아서 창의적인 방식으로 접근했지.")
        elif strategy == "전략 유지":
            lines.append("기억은 있지만 확신은 덜했기 때문에 조심스럽게 따랐어.")
        else:
            lines.append("이전 판단이 효과적이었기 때문에 그대로 따랐어.")
        lines.append(f"정확도는 {accuracy:.2f} 정도였고, 주된 감정은 '{self.emotion_engine.get_dominant_emotion()}'였어.")
        return " ".join(lines)

    def give_feedback(self, context: str, chosen_option: str, reward: float):
        context_embedding = self.embedding_model.encode([context])[0]
        options = ["option_"+str(i) for i in range(10)]  # 예시 옵션 리스트
        action_idx = options.index(chosen_option) if chosen_option in options else 0
        _, log_prob = self.rl_agent.select_action(context_embedding)

        self.rl_agent.store_transition((context_embedding.tolist(), action_idx, reward, log_prob))
        self.rl_agent.train_agent()
        logging.info(f"[DecisionEngine] 피드백 반영 완료: {chosen_option} → {reward:.2f}")