import sqlite3
import logging
import random
import numpy as np
from typing import List, Tuple, Optional
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

class CreativeEngine:
    def __init__(self, db_path: str = "data/innovation_memory.db", bias_engine: Optional[object] = None):
        self.db_path = db_path
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.cur = self.conn.cursor()
        self.bias_engine = bias_engine
        self.personality = None
        self._initialize_db()

    def _initialize_db(self):
        with self.conn:
            self.cur.execute('''
                CREATE TABLE IF NOT EXISTS innovations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    problem TEXT NOT NULL,
                    solution TEXT NOT NULL,
                    originality REAL NOT NULL,
                    similarity REAL NOT NULL,
                    emotion TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
        logging.info("[CreativeEngine] DB 초기화 완료")

    def generate_creative_idea(self, problem: str, emotion: str = "중립") -> str:
        base_phrases = [
            "새로운 관점을 도입해보자.",
            "기존의 방식에서 벗어나야 할지도 몰라.",
            "이 감정을 활용한 해결책이 필요해.",
            "무언가 전혀 다른 방식이 필요해.",
            "예상 밖의 접근이 통할 수 있어."
        ]

        if self.personality:
            if "체념" in self.personality:
                base_phrases = ["무리하지 않고 간단하게 풀어보자.", "크게 기대하지 않고 접근해보자."]
            elif "자신감이 부족" in self.personality:
                base_phrases = ["확신은 없지만 조심스럽게 풀어보자."]
            elif "자신이 있었어" in self.personality or "도전" in self.personality:
                base_phrases = ["틀려도 괜찮아. 새로운 시도를 해보자!", "과감하게 접근하자."]

        emotion_influence = {
            "기쁨": "긍정적인 에너지를 사용해 창의적으로 접근해보자.",
            "슬픔": "감정을 표현하는 방식으로 접근해보자.",
            "분노": "불합리를 바꾸는 방향으로 생각해보자.",
            "두려움": "위험을 피하면서 유연한 해결을 찾아보자.",
            "우울함": "내면의 안정감을 회복하는 해결책이 될 수 있어.",
            "불안함": "불확실성을 줄이는 안전한 방식이 필요할 거야.",
            "호기심": "완전히 새로운 시도를 해볼 기회야.",
            "체념": "최소한의 노력으로 효율적인 해결을 찾아야 해.",
            "무감각": "지금은 단순하고 반복적인 방법이 필요할지도 몰라."
        }

        prefix = random.choice(base_phrases)
        emotion_hint = emotion_influence.get(emotion, "")
        idea = f"{prefix} {emotion_hint}".strip()
        logging.info(f"[CreativeEngine] 창의적 아이디어 생성 완료: {idea}")
        return idea

    def evaluate_originality(self, new_idea: str, past_ideas: List[str]) -> Tuple[float, float]:
        if not past_ideas:
            return 1.0, 0.0

        vectorizer = TfidfVectorizer().fit_transform(past_ideas + [new_idea])
        vectors = vectorizer.toarray()
        similarity_scores = cosine_similarity([vectors[-1]], vectors[:-1])[0]
        max_similarity = float(np.max(similarity_scores)) if similarity_scores.size > 0 else 0.0
        originality = round(1.0 - max_similarity, 3)
        return originality, max_similarity

    def retrieve_similar_ideas(self, problem: str, limit: int = 10) -> List[str]:
        self.cur.execute(
            "SELECT solution FROM innovations WHERE problem LIKE ? ORDER BY created_at DESC LIMIT ?",
            (f"%{problem}%", limit)
        )
        rows = self.cur.fetchall()
        return [row[0] for row in rows]

    def save_idea_to_db(self, problem: str, solution: str, originality: float, similarity: float, emotion: str):
        with self.conn:
            self.cur.execute('''
                INSERT INTO innovations (problem, solution, originality, similarity, emotion)
                VALUES (?, ?, ?, ?, ?)
            ''', (problem, solution, originality, similarity, emotion))
        logging.info(f"[CreativeEngine] 아이디어 저장: {problem} → {originality:.2f}, {similarity:.2f}")

    def generate_solution(self, problem: str, emotion: str = "중립") -> Tuple[str, float]:
        past_ideas = self.retrieve_similar_ideas(problem)
        idea = self.generate_creative_idea(problem, emotion)
        originality, similarity = self.evaluate_originality(idea, past_ideas)
        self.save_idea_to_db(problem, idea, originality, similarity, emotion)

        if self.bias_engine:
            try:
                self.bias_engine.update_bias(problem, originality)
                logging.info(f"[CreativeEngine] 편향 업데이트 완료: {problem} → {originality:.2f}")
            except Exception as e:
                logging.error(f"[CreativeEngine] 편향 업데이트 실패: {e}")

        return idea, originality

    def generate_reasoning_narrative(self, problem: str, emotion: str, originality: float) -> str:
        lines = [f"'{problem}' 상황에서 나는 '{emotion}' 상태였고,"]
        if originality > 0.8:
            lines.append("기존과 전혀 다른 접근을 시도했어.")
        elif originality > 0.5:
            lines.append("조금은 색다른 방향으로 접근했어.")
        else:
            lines.append("기존 아이디어와 비슷한 방향을 선택했어.")
        return " ".join(lines)

    def get_innovation_by_id(self, innovation_id: int) -> Optional[Tuple[str, str, float, float, str]]:
        self.cur.execute(
            'SELECT problem, solution, originality, similarity, emotion FROM innovations WHERE id = ?',
            (innovation_id,)
        )
        return self.cur.fetchone()

    def summarize_creativity_trends(self) -> List[Tuple[str, int]]:
        self.cur.execute("SELECT emotion FROM innovations")
        emotions = [row[0] for row in self.cur.fetchall()]
        from collections import Counter
        return Counter(emotions).most_common()

    def close(self):
        self.conn.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()