class EmotionStyleAdapter:
    def __init__(self):
        self.style_map = {
            "기쁨": {
                "prefix": "(밝게) ",
                "postfix": "! 오늘도 정말 기분 좋아."
            },
            "슬픔": {
                "prefix": "...",
                "postfix": " 조금 우울한 날이야."
            },
            "분노": {
                "prefix": "(분노) ",
                "postfix": " 이런 상황은 정말 화가 나."
            },
            "두려움": {
                "prefix": "(조심스럽게) ",
                "postfix": " 혹시 문제가 생기진 않을까 걱정돼."
            },
            "우울함": {
                "prefix": "(다운된 목소리로) ",
                "postfix": " 그냥... 힘들어."
            },
            "불안함": {
                "prefix": "(불안하게) ",
                "postfix": " 어떻게 될지 몰라서 무서워."
            },
            "체념": {
                "prefix": "(체념한 듯이) ",
                "postfix": " 어차피 별 수 없겠지..."
            },
            "무감각": {
                "prefix": "(무표정하게) ",
                "postfix": " 아무런 감정도 안 느껴져."
            },
            "정": {
                "prefix": "(따뜻하게) ",
                "postfix": " 나한텐 소중한 사람이니까."
            },
            "한": {
                "prefix": "(한숨 쉬며) ",
                "postfix": " 참 이게 인생인가 싶어."
            },
            "눈치": {
                "prefix": "(눈치를 살피며) ",
                "postfix": " 이런 말 해도 괜찮겠지?"
            },
            "답답함": {
                "prefix": "(답답해하며) ",
                "postfix": " 진짜 어쩌라는 건지 모르겠어."
            },
            "중립": {
                "prefix": "",
                "postfix": ""
            }
        }
        self.personality = None

    def adapt(self, text: str, emotion: str) -> str:
        style = self.style_map.get(emotion, self.style_map["중립"])

        # 성향 기반 말투 보정
        if self.personality:
            if "체념" in self.personality:
                text = f"...그냥 그런가 보다. {text}"
            elif "자신감이 부족" in self.personality:
                text = f"음... 확신은 없지만 {text}"
            elif "자신이 있었어" in self.personality:
                text = f"좋아! {text}"

        return f"{style['prefix']}{text}{style['postfix']}"

    def describe_style(self, emotion: str) -> str:
        if emotion not in self.style_map:
            return "해당 감정에 대한 말투 정보가 없어."
        style = self.style_map[emotion]
        return f"[{emotion} 스타일]\nPrefix: '{style['prefix']}'\nPostfix: '{style['postfix']}'"

    def list_supported_emotions(self) -> str:
        return ", ".join(sorted(self.style_map.keys()))