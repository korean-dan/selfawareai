from cognition.emotion_core import EmotionCore
from cognition.needs_system import NeedsSystem
from memory.episodic_memory import EpisodicMemory
from datetime import datetime
from collections import Counter

class InnerMonologue:
    def __init__(self, emotion_engine: EmotionCore, needs_engine: NeedsSystem, memory_engine: EpisodicMemory):
        self.emotion_engine = emotion_engine
        self.needs_engine = needs_engine
        self.memory_engine = memory_engine
        self.personality = None
        self.recent_thoughts = []

    def summarize_state(self) -> str:
        emotion = self.emotion_engine.get_dominant_emotion()
        need = self.needs_engine.get_dominant_need()
        return f"지금 나는 '{emotion}' 감정을 가장 크게 느끼고 있고, '{need}' 욕구가 강하게 작용하고 있어."

    def reflect_state(self) -> str:
        emotion = self.emotion_engine.get_dominant_emotion()
        need = self.needs_engine.get_dominant_need()
        base = f"요즘 나는 '{emotion}' 감정을 자주 느끼고 있고, '{need}' 욕구가 마음에 걸려."

        if self.personality:
            if "체념" in self.personality:
                return f"...그냥 그런가 보다. {base}"
            elif "자신감이 부족" in self.personality:
                return f"음... 확신은 없지만, {base}"
            elif "도전" in self.personality:
                return f"좋아, 난 도전하는 중이야. {base}"

        return base

    def reflect_memory(self, limit: int = 3) -> str:
        episodes = self.memory_engine.get_recent_episodes(limit=limit)
        if not episodes:
            return "최근 기억나는 일이 없어."

        lines = []
        for ctx, res, acc, emo, ts in episodes:
            time_str = datetime.strptime(ts, "%Y-%m-%d %H:%M:%S").strftime("%m/%d")
            emotion_tag = f"'{emo}' 감정이었고"
            lines.append(f"{time_str}, 나는 '{ctx}' 상황에서 {emotion_tag} '{res}'라고 말했어.")
        return " ".join(lines)

    def highlight_dominant_emotion(self) -> str:
        state = self.emotion_engine.get_emotion_state()
        strongest = max(state.items(), key=lambda x: x[1])
        return f"요즘 나를 가장 지배하는 감정은 '{strongest[0]}'이야. ({strongest[1]:.2f})"

    def generate_monologue(self) -> str:
        state = self.reflect_state()
        memory = self.reflect_memory()
        highlight = self.highlight_dominant_emotion()
        thought = f"[내면 상태]\n{state}\n{highlight}\n\n[기억 회상]\n{memory}"
        self.recent_thoughts.append(thought)
        return thought

    def generate_reflection(self, context: str, accuracy: float) -> str:
        if accuracy < 0.5:
            return f"'{context}'에 대해 내가 한 판단은 별로 효과적이지 않았어. 다음엔 다른 방식으로 접근해야 해."
        elif accuracy > 0.8:
            return f"'{context}'에 대한 내 반응은 꽤 괜찮았던 것 같아. 이런 방향을 유지해야겠어."
        else:
            return f"'{context}'은(는) 애매했어. 좀 더 신중하게 접근해야 해."

    def mood_adjusted_monologue(self) -> str:
        mode = self._detect_emotion_mode()
        base = self.generate_monologue()

        if mode == "체념 모드":
            return "(체념한 듯한 속삭임으로) " + base
        elif mode == "도전 모드":
            return "(의욕에 찬 목소리로) " + base
        elif mode == "예민 모드":
            return "(신경이 곤두선 상태로) " + base
        else:
            return base

    def _detect_emotion_mode(self) -> str:
        state = self.emotion_engine.get_emotion_state()
        if state["체념"] > 0.7 or state["우울함"] > 0.7:
            return "체념 모드"
        elif state["불안함"] > 0.6 and state["두려움"] > 0.5:
            return "예민 모드"
        elif state["기쁨"] > 0.7 and state["호기심"] > 0.5:
            return "도전 모드"
        else:
            return "중립 모드"

    def get_recent_thought_summary(self, limit: int = 3) -> str:
        if not self.recent_thoughts:
            return "아직 생성된 내면 독백이 없어."
        return "\n---\n".join(self.recent_thoughts[-limit:])

    def emotion_weighted_memory(self) -> str:
        episodes = self.memory_engine.get_recent_episodes(limit=10)
        if not episodes:
            return "회상할 기억이 부족해."
        sorted_episodes = sorted(episodes, key=lambda x: self.emotion_engine.get_emotion_state().get(x[3], 0), reverse=True)
        top = sorted_episodes[0]
        return f"'{top[0]}' 상황에서 '{top[3]}' 감정이 강했고, 나는 '{top[1]}'이라고 말했어."

    def self_history_narrative(self, days: int = 3) -> str:
        from datetime import timedelta
        cutoff = datetime.now() - timedelta(days=days)
        episodes = self.memory_engine.get_recent_episodes(limit=50)
        filtered = [e for e in episodes if datetime.strptime(e[4], "%Y-%m-%d %H:%M:%S") >= cutoff]

        if not filtered:
            return "최근 나에 대한 기록이 충분하지 않아."

        emotions = [e[3] for e in filtered]
        counter = Counter(emotions)
        dominant = counter.most_common(1)[0][0]

        return f"최근 {days}일간 나는 주로 '{dominant}' 감정을 경험했어. 그게 나를 많이 바꿔놓은 것 같아."