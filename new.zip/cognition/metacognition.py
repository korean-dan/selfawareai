import sqlite3
import logging
from typing import Dict
from datetime import datetime, timedelta

class MetaCognition:
    def __init__(self, db_path: str = "data/human_meta_cognition.db"):
        self.db_path = db_path
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.cur = self.conn.cursor()
        self.bias: Dict[str, float] = {}
        self._initialize_db()
        self._load_bias()

    def _initialize_db(self):
        with self.conn:
            self.cur.execute('''
                CREATE TABLE IF NOT EXISTS biases (
                    bias_type TEXT PRIMARY KEY,
                    weight REAL CHECK(weight BETWEEN -1 AND 1),
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')

    def _load_bias(self):
        self.cur.execute("SELECT bias_type, weight FROM biases ORDER BY updated_at DESC LIMIT 100")
        records = self.cur.fetchall()
        for bias_type, weight in records:
            self.bias[bias_type] = weight
        logging.info(f"[MetaCognition] 최근 편향 {len(self.bias)}건 로드됨")

    def update_bias(self, context: str, accuracy: float):
        if context not in self.bias:
            self.bias[context] = 0.0

        delta = (accuracy - 0.5) * 0.1
        updated = max(-1.0, min(1.0, self.bias[context] + delta))
        self.bias[context] = updated

        try:
            with self.conn:
                self.cur.execute(
                    '''
                    INSERT INTO biases (bias_type, weight, updated_at)
                    VALUES (?, ?, ?)
                    ON CONFLICT(bias_type) DO UPDATE SET
                        weight=excluded.weight,
                        updated_at=excluded.updated_at
                    ''',
                    (context, updated, datetime.now())
                )
            logging.info(f"[MetaCognition] '{context}' 편향 업데이트: {updated:.3f}")
        except sqlite3.Error as e:
            logging.error(f"[MetaCognition] 편향 업데이트 오류: {e}")

    def get_bias(self, context: str) -> float:
        return self.bias.get(context, 0.0)

    def get_bias_trends(self) -> Dict[str, float]:
        return dict(sorted(self.bias.items(), key=lambda x: abs(x[1]), reverse=True))

    def get_top_n_biases(self, n: int = 5) -> Dict[str, float]:
        return dict(sorted(self.bias.items(), key=lambda x: abs(x[1]), reverse=True)[:n])

    def forget_old_biases(self, days: int = 30):
        cutoff = datetime.now() - timedelta(days=days)
        try:
            with self.conn:
                self.cur.execute(
                    'DELETE FROM biases WHERE updated_at < ?',
                    (cutoff.isoformat(),)
                )
            logging.info(f"[MetaCognition] {days}일 초과된 오래된 편향 삭제 완료")
        except sqlite3.Error as e:
            logging.error(f"[MetaCognition] 오래된 편향 삭제 오류: {e}")

    def close(self):
        self.conn.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()